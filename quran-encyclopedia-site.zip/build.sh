#!/usr/bin/env bash
# بناء قاعدة البيانات للنشر (بدون PDF/تقرير: لا يلزم Chromium)
set -e
pip install -r requirements-deploy.txt
python -m qenc stage import
python -m qenc stage index
python -m qenc stage themes
python -m qenc stage verify
