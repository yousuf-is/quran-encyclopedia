"""يبني قاعدة بيانات اختبار مؤقتة (مرة واحدة لكل عملية اختبار) دون المساس بقاعدة الإنتاج."""
import sys, tempfile, pathlib, hashlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from qenc import db, importer, indexer
from qenc.themes import assign

_cache = {}


def build(tag="main"):
    if tag in _cache:
        return _cache[tag]
    d = pathlib.Path(tempfile.mkdtemp(prefix=f"qenc_test_{tag}_"))
    con = db.connect(d / "t.db"); db.init_schema(con)
    importer.run(con); indexer.run(con); assign.run(con)
    _cache[tag] = (con, d / "t.db")
    return _cache[tag]


def content_hash(con) -> str:
    """بصمة محتوى الجداول الحتمية (تستثني الطوابع الزمنية ومعرّفات التشغيل)."""
    h = hashlib.sha256()
    queries = [
        "SELECT * FROM chapters ORDER BY id", "SELECT id,surah,ayah,text_original,text_sha256,basmalah_prefix_words,word_count FROM verses ORDER BY id",
        "SELECT * FROM words ORDER BY id", "SELECT * FROM word_search ORDER BY word_id",
        "SELECT id,root,letters,word_count,verse_count FROM roots ORDER BY id", "SELECT id,lemma,lemma_norm,pos,root_id,word_count,verse_count FROM lexical_entries ORDER BY id",
        "SELECT word_id,seg_index,corpus_ref,form_text,pos_tag,features_raw,is_stem,lemma_id,root_id,align_status FROM morph_analyses ORDER BY word_id,seg_index",
        "SELECT * FROM word_forms ORDER BY id", "SELECT * FROM word_roots ORDER BY word_id,root_id", "SELECT * FROM word_lemmas ORDER BY word_id,lemma_id",
        "SELECT verse_id,topic_id,role,relevance,rationale,evidence_word_ids,method,confidence FROM verse_topics ORDER BY verse_id,topic_id,method",
        "SELECT * FROM intersection_index ORDER BY kind,key,topic_id,relevance",
    ]
    for q in queries:
        for r in con.execute(q):
            h.update(repr(tuple(r)).encode())
    return h.hexdigest()
