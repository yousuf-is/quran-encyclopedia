import unittest
from tests._build import build
from qenc import search


class KnownSamples(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.con, _ = build()

    def q1(self, sql, *a):
        return self.con.execute(sql, a).fetchone()[0]

    def test_surah_verse_counts(self):
        for s, n in {1: 7, 2: 286, 3: 200, 9: 129, 36: 83, 108: 3, 112: 4, 114: 6}.items():
            self.assertEqual(self.q1("SELECT COUNT(*) FROM verses WHERE surah=?", s), n, s)
        self.assertEqual(self.q1("SELECT COUNT(*) FROM verses"), 6236)

    def test_fatiha_first_verse(self):
        ws = [r[0] for r in self.con.execute("SELECT text_original FROM words WHERE verse_id=1001 ORDER BY pos")]
        self.assertEqual(len(ws), 4)
        self.assertEqual(self.q1("SELECT basmalah_prefix_words FROM verses WHERE id=1001"), 0)

    def test_basmalah_separated_in_other_surahs(self):
        self.assertEqual(self.q1("SELECT basmalah_prefix_words FROM verses WHERE id=2001"), 4)
        self.assertEqual(self.q1("SELECT basmalah_prefix_words FROM verses WHERE id=9001"), 0)
        self.assertEqual(self.q1("SELECT word_count FROM verses WHERE id=112001"), 4)       # قُلْ هُوَ ٱللَّهُ أَحَدٌ

    def test_ayat_alkursi_words(self):
        self.assertEqual(self.q1("SELECT word_count FROM verses WHERE id=2255"), 50)

    def test_rahman_normalized_search(self):
        rows = search.normalized(self.con, "الرحمن")
        refs = {(r["surah"], r["ayah"]) for r in rows}
        self.assertIn((1, 1), refs); self.assertIn((1, 3), refs)

    def test_root_rahm_forms(self):
        lemmas = {f["lemma"] for f in search.forms_of(self.con, "رحم")}
        self.assertTrue(any("رَحِيم" in l for l in lemmas) and any("رَحْمٰن" in l or "رَحْمَٰن" in l for l in lemmas), lemmas)

    def test_literal_vs_normalized_differ(self):
        form = self.con.execute("SELECT text_original FROM words WHERE text_original LIKE 'ٱل%' AND instr(text_original, char(1600))>0 AND instr(text_original, char(1620))>0 GROUP BY text_original ORDER BY COUNT(*) DESC LIMIT 1").fetchone()[0]
        lit = search.literal(self.con, form)
        nrm = search.normalized(self.con, "الآخرة")
        self.assertTrue(lit and len(nrm) > len(lit))
        self.assertTrue(all(r["text_original"] == form for r in lit))

    def test_literal_survives_unicode_representation(self):
        import unicodedata
        form = self.con.execute("SELECT text_original FROM words WHERE instr(text_original, char(1600))>0 LIMIT 1").fetchone()[0]
        base = {r["word_id"] for r in search.literal(self.con, form)}
        for v in (unicodedata.normalize("NFC", form), unicodedata.normalize("NFD", form)):
            self.assertEqual({r["word_id"] for r in search.literal(self.con, v)}, base)

    def test_unresolved_documented(self):
        refs = {r[0] for r in self.con.execute("SELECT ref FROM error_log WHERE severity IN ('warning','unresolved')")}
        self.assertTrue({"12:39", "12:41", "37:130:4"} <= refs)


if __name__ == "__main__":
    unittest.main()
