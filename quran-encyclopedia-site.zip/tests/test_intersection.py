import unittest
from tests._build import build
from qenc import intersect, search


class Intersection(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.con, _ = build()

    def lexset(self, q, lvl_max):
        order = ["literal", "normalized", "morphological", "derivational"]
        return {r["verse_id"] for l in order[:order.index(lvl_max) + 1] for r in search.search(self.con, q, l)}

    def test_both_conditions_and_no_duplicates(self):
        for q, t in (("مُوسَىٰ", "f_musa_harun"), ("رحم", "akhirah"), ("أمن", "g_mumin"), ("صلاة", "salah")):
            r = intersect.intersect(self.con, q, t, relevance="all")
            lex = self.lexset(q, "derivational"); th = {x["verse_id"] for x in intersect.topic_rows(self.con, t, True, "all")}
            ids = [x["verse_id"] for x in r["intersection"]]
            self.assertEqual(len(ids), len(set(ids))); self.assertEqual(ids, sorted(ids))
            self.assertTrue(set(ids) <= lex & th)
            self.assertEqual(set(ids), lex & th)                       # التقاطع الحقيقي كاملًا لا ناقصًا

    def test_categories(self):
        r = intersect.intersect(self.con, "مُوسَىٰ", "f_musa_harun")
        self.assertGreater(r["counts"]["أ"], 50)
        for row in r["intersection"]:
            if row["category"] == "أ":
                self.assertIn(row["lexical_level"], ("literal", "normalized"))
                self.assertTrue(any(a["relevance"] == "direct" for a in row["topic_assignments"]))
            if row["category"] == "ب":
                self.assertIn(row["lexical_level"], ("morphological", "derivational"))

    def test_contextual_excluded_by_default(self):
        r = intersect.intersect(self.con, "رحم", "akhirah")
        for row in r["intersection"]:
            self.assertTrue(all(a["relevance"] != "contextual" for a in row["topic_assignments"]))
        r2 = intersect.intersect(self.con, "رحم", "akhirah", relevance="all")
        self.assertGreater(len(r2["intersection"]), len(r["intersection"]))

    def test_synonyms_separate(self):
        lit = {r["word_id"] for l in ("literal", "normalized", "morphological", "derivational") for r in search.search(self.con, "خوف", l)}
        sem = search.semantic(self.con, "خوف")
        self.assertTrue(sem)
        self.assertFalse({r["word_id"] for r in sem} & lit)
        self.assertTrue(all(r["level"] == "semantic" for r in sem))

    def test_literal_never_contains_synonyms(self):
        for r in search.literal(self.con, "خَوْفٌ"):
            self.assertEqual(r["level"], "literal")

    def test_descendants(self):
        a = {v["verse_id"] for v in intersect.topic_verses(self.con, "anbiya", True, "indirect")}
        b = {v["verse_id"] for v in intersect.topic_verses(self.con, "anbiya", False, "indirect")}
        self.assertTrue(b <= a and len(a) > len(b))


if __name__ == "__main__":
    unittest.main()
