import unittest, shutil
from tests._build import build, content_hash
from qenc import db, importer, indexer, pipeline
from qenc.themes import assign


class Reproducible(unittest.TestCase):
    def test_two_independent_builds_identical(self):
        con1, _ = build("a"); con2, _ = build("b")
        self.assertEqual(content_hash(con1), content_hash(con2))

    def test_resume_after_partial_morph_import(self):
        con, _ = build("resume")
        before = content_hash(con)
        # محاكاة انقطاع: فقدان جزء من التحليل الصرفي
        con.execute("DELETE FROM word_topic_links"); con.execute("DELETE FROM morph_analyses WHERE id % 7 = 0"); con.commit()
        self.assertNotEqual(con.execute("SELECT COUNT(*) FROM morph_analyses").fetchone()[0], 130030)
        importer.run(con); indexer.run(con); assign.run(con)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM morph_analyses").fetchone()[0], 130030)
        self.assertEqual(content_hash(con), before)

    def test_stage_skip_when_done(self):
        con, _ = build("skip")
        s1 = pipeline.run_stage(con, "import"); s2 = pipeline.run_stage(con, "import")
        self.assertFalse(s1.get("skipped")); self.assertTrue(s2.get("skipped"))

    def test_human_review_survives_reindex(self):
        con, _ = build("review")
        vt = con.execute("SELECT id FROM verse_topics WHERE method='seed_curated' LIMIT 1").fetchone()[0]
        con.execute("UPDATE verse_topics SET review_status='human_confirmed' WHERE id=?", (vt,)); con.commit()
        assign.run(con)
        self.assertEqual(con.execute("SELECT review_status FROM verse_topics WHERE id=?", (vt,)).fetchone()[0], "human_confirmed")

    def test_original_text_cannot_be_modified(self):
        con, _ = build("immut")
        with self.assertRaises(Exception):
            con.execute("UPDATE verses SET text_original='x' WHERE id=1001")
        con.rollback()


if __name__ == "__main__":
    unittest.main()
