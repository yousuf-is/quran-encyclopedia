import unittest
from tests._build import build
from qenc import verify


class FullQuran(unittest.TestCase):
    def test_all_automatic_checks_pass(self):
        con, _ = build()
        res = verify.run_all(con)
        failed = [r for r in res if not r["ok"]]
        self.assertFalse(failed, failed)
        self.assertGreaterEqual(len(res), 20)


if __name__ == "__main__":
    unittest.main()
