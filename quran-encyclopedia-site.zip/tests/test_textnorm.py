import unittest
from tests import _build  # noqa (sys.path)
from qenc.textnorm import normalize_v1, skeleton


class TextNorm(unittest.TestCase):
    def test_known_samples(self):
        self.assertEqual(normalize_v1("ٱلرَّحْمَٰنِ"), "الرحمن")
        self.assertEqual(normalize_v1("بِسْمِ"), "بسم")
        self.assertEqual(normalize_v1("فِى"), "في")                      # ى → ي
        self.assertEqual(normalize_v1("ٱلْـَٔاخِرَةِ"), normalize_v1("ٱلْءَاخِرَةِ"))  # رسمان لكلمة واحدة
        self.assertEqual(normalize_v1("الآخرة"), normalize_v1("ٱلْءَاخِرَةِ"))       # آ = ءا
        self.assertEqual(normalize_v1("إِبْرَٰهِـۧمَ"), normalize_v1("إِبْرَٰهِۦمَ"))

    def test_idempotent(self):
        for w in ["ٱلرَّحْمَٰنِ", "وَبِٱلْـَٔاخِرَةِ", "يُبَدِّلُونَهُۥٓ", "قُلْ"]:
            self.assertEqual(normalize_v1(normalize_v1(w)), normalize_v1(w))

    def test_skeleton_weaker_than_norm(self):
        self.assertEqual(skeleton("ءَاخِرَة"), skeleton("ٱلْـَٔاخِرَة")[2:] if False else skeleton("ءَاخِرَة"))
        self.assertNotIn("ء", skeleton("ءَامَنُوا"))


if __name__ == "__main__":
    unittest.main()
