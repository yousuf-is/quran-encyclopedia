"""الواجهة العربية (RTL). لا تستدعي أي نموذج ذكاء اصطناعي: كل شيء من الفهارس وقاعدة البيانات."""
from __future__ import annotations
import io, json, sqlite3, tempfile
from pathlib import Path
from flask import Flask, render_template, request, abort, send_file, redirect, url_for, Response
from markupsafe import Markup, escape
from .. import config, db, search, intersect, export
from ..util import now

LEVEL_NAMES = {"literal": "حرفية", "normalized": "مطبّعة (ن١)", "morphological": "صرفية (اللمّة)", "derivational": "اشتقاقية (الجذر)", "semantic": "دلالية/مرادفات (منفصلة)"}
REL_NAMES = {"direct": "مباشرة فقط", "indirect": "مباشرة + جوهرية غير مباشرة", "all": "تشمل السياقية"}
STATUS_NAMES = {"": "كل الحالات", "unreviewed": "غير مراجَع", "human_confirmed": "مؤكَّد بشريًا", "disputed": "محل خلاف", "rejected": "مرفوض"}
REL_AR = {"direct": "مباشرة", "substantive_indirect": "جوهرية غير مباشرة", "contextual": "سياقية"}


def create_app():
    app = Flask(__name__, template_folder=str(Path(__file__).parent / "templates"))
    app.config["JSON_AS_ASCII"] = False

    def con_ro():
        return db.connect(readonly=True)

    @app.template_filter("relar")
    def relar(v): return REL_AR.get(v, v)

    def verse_html(con, vid, highlight=()):
        v = con.execute("SELECT text_original, basmalah_prefix_words FROM verses WHERE id=?", (vid,)).fetchone()
        toks = v[0].split(" ")
        pref = v[1]
        hl = set(highlight)
        out = []
        for i, t in enumerate(toks):
            pos = i - pref + 1
            cls = "pre" if i < pref else ("hit" if pos in hl else "")
            out.append(f'<span class="{cls}">{escape(t)}</span>')
        return Markup(" ".join(out))

    app.jinja_env.globals.update(LEVEL_NAMES=LEVEL_NAMES, REL_NAMES=REL_NAMES, STATUS_NAMES=STATUS_NAMES)

    def maybe_export(cols, rows, title, base, meta=None):
        fmt = request.args.get("format")
        if not fmt:
            return None
        if fmt not in ("csv", "json", "xlsx", "html", "pdf"):
            abort(400)
        d = Path(tempfile.mkdtemp(prefix="qenc_"))
        res = export.write_all(d / base, cols, rows, title, meta, formats=(fmt,))
        path = res.get(fmt)
        if not path or not Path(path).exists():
            return Response(f"تعذّر التصدير: {path}", status=501, mimetype="text/plain; charset=utf-8")
        return send_file(path, as_attachment=True, download_name=Path(path).name)

    def status_filter(rows, status):
        if not status:
            return rows
        out = []
        for r in rows:
            a = [x for x in r["topic_assignments"] if x["review_status"] == status] if "topic_assignments" in r else None
            if a:
                r = dict(r); r["topic_assignments"] = a; out.append(r)
        return out

    @app.route("/")
    def home():
        con = con_ro()
        stats = {"آيات": con.execute("SELECT COUNT(*) FROM verses").fetchone()[0], "كلمات": con.execute("SELECT COUNT(*) FROM words").fetchone()[0],
                 "جذور": con.execute("SELECT COUNT(*) FROM roots").fetchone()[0], "موضوعات": con.execute("SELECT COUNT(*) FROM topics").fetchone()[0]}
        topics = [dict(r) for r in con.execute("SELECT slug, name_ar, parent_id FROM topics ORDER BY id")]
        return render_template("home.html", stats=stats, topics=topics)

    @app.route("/word")
    def word():
        q = request.args.get("q", "").strip(); level = request.args.get("level", "normalized")
        if level not in search.LEVELS: abort(400)
        con = con_ro(); rows = search.search(con, q, level) if q else []
        cols = [("surah", "السورة"), ("ayah", "الآية"), ("pos", "الموضع"), ("text_original", "اللفظ"), ("level", "المستوى"), ("reason", "السبب"), ("verse_text", "نص الآية")]
        ex = maybe_export(cols, rows, f"بحث {q}", f"word_{level}", {"مستوى": LEVEL_NAMES[level]}) if q else None
        if ex: return ex
        hits = search.verse_hits(rows)
        for h in hits: h["html"] = verse_html(con, h["verse_id"], h["positions"])
        forms = {}
        for r in rows: forms[r["text_original"]] = forms.get(r["text_original"], 0) + 1
        return render_template("word.html", q=q, level=level, rows=rows, hits=hits, forms=sorted(forms.items(), key=lambda x: -x[1]))

    @app.route("/root")
    def root():
        q = request.args.get("q", "").strip(); con = con_ro()
        forms = search.forms_of(con, q) if q else []
        cols = [("lemma", "اللمّة"), ("pos", "النوع"), ("form", "الصيغة"), ("occurrences", "مرات الورود"), ("verses", "عدد الآيات")]
        ex = maybe_export(cols, forms, f"جذر {q}", "root_forms") if q else None
        if ex: return ex
        info = con.execute("SELECT word_count, verse_count FROM roots WHERE root=?", (q,)).fetchone() if q else None
        grouped = {}
        for f in forms: grouped.setdefault((f["lemma"], f["pos"]), []).append(f)
        return render_template("root.html", q=q, info=info, grouped=grouped)

    @app.route("/topic")
    def topic():
        slug = request.args.get("slug", ""); rel = request.args.get("relevance", "indirect"); status = request.args.get("status", "")
        desc = request.args.get("desc", "1") == "1"; con = con_ro()
        topics = [dict(r) for r in con.execute("SELECT slug, name_ar FROM topics ORDER BY id")]
        res = []
        if slug:
            try: res = intersect.topic_verses(con, slug, desc, rel)
            except KeyError: abort(404)
            if status: res = [dict(v, assignments=[a for a in v["assignments"] if a["review_status"] == status]) for v in res if any(a["review_status"] == status for a in v["assignments"])]
        cols = [("surah", "السورة"), ("ayah", "الآية"), ("verse_text", "نص الآية"), ("topics", "الإسنادات"), ("rationale", "وجه الصلة")]
        rows = [{"surah": v["surah"], "ayah": v["ayah"], "verse_text": v["verse_text"],
                 "topics": "؛ ".join(sorted({f"{a['name_ar']} [{a['relevance']}/{a['method']}/{a['review_status']}]" for a in v["assignments"]})),
                 "rationale": " | ".join(a["rationale"] or "" for a in v["assignments"])[:500]} for v in res]
        ex = maybe_export(cols, rows, f"موضوع {slug}", f"topic_{slug}") if slug else None
        if ex: return ex
        for v in res: v["html"] = verse_html(con, v["verse_id"])
        lex = {}
        if slug and res:
            ids = [v["verse_id"] for v in res]
            q = ",".join("?" * len(ids))
            for r in con.execute(f"SELECT COALESCE(le.lemma,w.text_original) AS k, COUNT(*) n FROM words w LEFT JOIN word_lemmas wl ON wl.word_id=w.id LEFT JOIN lexical_entries le ON le.id=wl.lemma_id WHERE w.verse_id IN ({q}) AND (le.pos IN ('N','V') OR le.pos IS NULL) GROUP BY k ORDER BY n DESC LIMIT 25", ids):
                lex[r["k"]] = r["n"]
        return render_template("topic.html", slug=slug, rel=rel, status=status, desc=desc, topics=topics, res=res, lex=lex)

    @app.route("/combo")
    def combo():
        q = request.args.get("q", "").strip(); slug = request.args.get("slug", "")
        lvl = request.args.get("level", "derivational"); rel = request.args.get("relevance", "indirect"); status = request.args.get("status", "")
        if lvl not in ("literal", "normalized", "morphological", "derivational"): abort(400)
        con = con_ro()
        topics = [dict(r) for r in con.execute("SELECT slug, name_ar FROM topics ORDER BY id")]
        res = None
        if q and slug:
            try: res = intersect.intersect(con, q, slug, lvl, True, rel)
            except KeyError: abort(404)
            res["intersection"] = status_filter(res["intersection"], status); res["synonym_set"] = status_filter(res["synonym_set"], status)
            cols, rows = export.result_rows(res)
            ex = maybe_export(cols, rows, f"تقاطع {q} × {slug}", f"combo_{slug}", {"مستوى المطابقة": LEVEL_NAMES[lvl], "الصلة": REL_NAMES[rel]})
            if ex: return ex
            for r in res["intersection"]: r["html"] = verse_html(con, r["verse_id"], [w["pos"] for w in r["words"]])
            for r in res["synonym_set"]: r["html"] = verse_html(con, r["verse_id"], [w["pos"] for w in r["words"]])
        return render_template("combo.html", q=q, slug=slug, lvl=lvl, rel=rel, status=status, topics=topics, res=res)

    @app.route("/verse/<int:s>/<int:a>")
    def verse(s, a):
        con = con_ro(); vid = s * 1000 + a
        v = con.execute("SELECT v.*, c.name_ar FROM verses v JOIN chapters c ON c.id=v.surah WHERE v.id=?", (vid,)).fetchone()
        if not v: abort(404)
        words = []
        for w in con.execute("SELECT id, pos, text_original FROM words WHERE verse_id=? ORDER BY pos", (vid,)):
            segs = [dict(r) for r in con.execute("SELECT m.form_text, m.pos_tag, m.features_raw, m.align_status, le.lemma, r.root FROM morph_analyses m LEFT JOIN lexical_entries le ON le.id=m.lemma_id LEFT JOIN roots r ON r.id=m.root_id WHERE m.word_id=? ORDER BY m.seg_index", (w["id"],))]
            nrm = con.execute("SELECT text_norm FROM word_search WHERE word_id=?", (w["id"],)).fetchone()[0]
            words.append({"pos": w["pos"], "text": w["text_original"], "norm": nrm, "segs": segs})
        tops = [dict(r) for r in con.execute("""SELECT vt.id, t.slug, t.name_ar, vt.role, vt.relevance, vt.rationale, vt.method, vt.confidence, vt.review_status, vt.machine_generated
                                               FROM verse_topics vt JOIN topics t ON t.id=vt.topic_id WHERE vt.verse_id=? ORDER BY CASE vt.relevance WHEN 'direct' THEN 0 WHEN 'substantive_indirect' THEN 1 ELSE 2 END, vt.confidence DESC""", (vid,))]
        neigh = (vid - 1 if con.execute("SELECT 1 FROM verses WHERE id=?", (vid - 1,)).fetchone() else None, vid + 1 if con.execute("SELECT 1 FROM verses WHERE id=?", (vid + 1,)).fetchone() else None)
        return render_template("verse.html", v=v, words=words, tops=tops, neigh=neigh, html=verse_html(con, vid))

    @app.route("/surah/<int:n>")
    def surah(n):
        con = con_ro()
        c = con.execute("SELECT * FROM chapters WHERE id=?", (n,)).fetchone()
        if not c: abort(404)
        vs = [dict(r) for r in con.execute("SELECT id, ayah FROM verses WHERE surah=? ORDER BY ayah", (n,))]
        for v in vs: v["html"] = verse_html(con, v["id"])
        return render_template("surah.html", c=c, vs=vs, chapters=[dict(r) for r in con.execute("SELECT id, name_ar FROM chapters ORDER BY id")])

    @app.route("/sources")
    def sources():
        con = con_ro()
        return render_template("sources.html", src=[dict(r) for r in con.execute("SELECT * FROM source_versions ORDER BY id")],
                               issues=[dict(r) for r in con.execute("SELECT stage, severity, ref, message FROM error_log ORDER BY id")])

    @app.route("/report")
    def report_page():
        p = config.REPORT_DIR / "final_report.html"
        if not p.exists(): abort(404)
        return Response(p.read_text(encoding="utf-8"), mimetype="text/html; charset=utf-8")

    @app.route("/review", methods=["POST"])
    def review():
        """مراجعة بشرية لإسناد: تُسجَّل في review_log ولا تُمحى عند إعادة الفهرسة."""
        vt = int(request.form["vt_id"]); status = request.form["status"]
        if status not in ("human_confirmed", "rejected", "disputed", "unreviewed"): abort(400)
        reviewer = request.form.get("reviewer", "").strip() or "غير مسمّى"; note = request.form.get("note", "").strip()
        con = db.connect()
        row = con.execute("SELECT review_status, verse_id FROM verse_topics WHERE id=?", (vt,)).fetchone()
        if not row: abort(404)
        with db.tx(con):
            con.execute("UPDATE verse_topics SET review_status=? WHERE id=?", (status, vt))
            con.execute("INSERT INTO review_log(entity_type,entity_id,old_value,new_value,reviewer,note,ts) VALUES('verse_topic',?,?,?,?,?,?)", (vt, row["review_status"], status, reviewer, note, now()))
            if note:
                con.execute("INSERT INTO evidence_notes(entity_type,entity_id,note,author,created_at) VALUES('verse_topic',?,?,?,?)", (vt, note, reviewer, now()))
        v = row["verse_id"]
        return redirect(url_for("verse", s=v // 1000, a=v % 1000))

    return app
