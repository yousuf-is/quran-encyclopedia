"""مخطط قاعدة البيانات (SQLite) والاتصال بها.

الفصل بين الطبقات:
  - حقائق نصية:      chapters, verses, words           (لا تُعدَّل: مفعّلة بمشغّلات منع التعديل)
  - تحليل صرفي:      segments(=morph_analyses), lexical_entries, roots
  - تصنيف موضوعي:   topics, topic_relations, verse_topics, word_topic_links
  - اجتهاد تفسيري:   tafsir_sources, tafsir_refs
  - إدارة:          source_versions, runs, error_log, review_log, stage_state
"""
from __future__ import annotations
import sqlite3
from contextlib import contextmanager
from . import config

SCHEMA = r"""
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS source_versions(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL, version TEXT, url TEXT,
  local_path TEXT, sha256 TEXT NOT NULL, bytes INTEGER, license TEXT, license_status TEXT,
  attribution TEXT, notes TEXT, imported_at TEXT NOT NULL,
  UNIQUE(name, sha256)
);

CREATE TABLE IF NOT EXISTS chapters(
  id INTEGER PRIMARY KEY, name_ar TEXT NOT NULL, name_translit TEXT, name_en TEXT,
  revelation_type TEXT, verse_count INTEGER NOT NULL, source_id INTEGER REFERENCES source_versions(id)
);

-- النص الأصلي كما ورد في المصدر حرفيًا (آية كاملة، وتشمل البسملة المسبوقة إن كان المصدر يسبقها بها)
CREATE TABLE IF NOT EXISTS verses(
  id INTEGER PRIMARY KEY,                       -- سورة*1000 + آية
  surah INTEGER NOT NULL REFERENCES chapters(id), ayah INTEGER NOT NULL,
  text_original TEXT NOT NULL, text_sha256 TEXT NOT NULL,
  basmalah_prefix_words INTEGER NOT NULL DEFAULT 0,   -- عدد كلمات البسملة المسبوقة في المصدر وغير المحسوبة ضمن words
  word_count INTEGER NOT NULL, source_id INTEGER REFERENCES source_versions(id),
  UNIQUE(surah, ayah)
);

-- كلمات الآية (رموز نص تنزيل بعد فصل البسملة المسبوقة) — النص الأصلي حرفيًا
CREATE TABLE IF NOT EXISTS words(
  id INTEGER PRIMARY KEY,                       -- سورة*1e6 + آية*1e3 + موضع
  verse_id INTEGER NOT NULL REFERENCES verses(id), pos INTEGER NOT NULL,
  text_original TEXT NOT NULL,
  UNIQUE(verse_id, pos)
);
CREATE INDEX IF NOT EXISTS idx_words_verse ON words(verse_id);

-- نسخة البحث المطبّعة: منفصلة تمامًا عن النص الأصلي
CREATE TABLE IF NOT EXISTS word_search(
  word_id INTEGER PRIMARY KEY REFERENCES words(id), text_norm TEXT NOT NULL, norm_version TEXT NOT NULL,
  text_nfd TEXT   -- مفتاح تكافؤ قانوني (NFD) للبحث الحرفي: يوحّد التمثيل الرقمي للعلامات دون حذف أي حرف
);
CREATE INDEX IF NOT EXISTS idx_wsearch_norm ON word_search(text_norm);
CREATE TABLE IF NOT EXISTS verse_search(
  verse_id INTEGER PRIMARY KEY REFERENCES verses(id), text_norm TEXT NOT NULL, norm_version TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS roots(
  id INTEGER PRIMARY KEY, root TEXT NOT NULL UNIQUE, letters INTEGER NOT NULL,
  word_count INTEGER NOT NULL DEFAULT 0, verse_count INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS lexical_entries(      -- المداخل المعجمية (اللمّات)
  id INTEGER PRIMARY KEY, lemma TEXT NOT NULL, lemma_norm TEXT NOT NULL, pos TEXT,
  root_id INTEGER REFERENCES roots(id), word_count INTEGER NOT NULL DEFAULT 0,
  verse_count INTEGER NOT NULL DEFAULT 0, UNIQUE(lemma, pos, root_id)
);
CREATE INDEX IF NOT EXISTS idx_lex_norm ON lexical_entries(lemma_norm);

-- التحليل الصرفي: جزء (segment) لكل صف. التحليل المنقول من المصدر لا يُعدّل هنا.
CREATE TABLE IF NOT EXISTS morph_analyses(
  id INTEGER PRIMARY KEY, word_id INTEGER NOT NULL REFERENCES words(id),
  seg_index INTEGER NOT NULL, corpus_ref TEXT NOT NULL,         -- س:آ:ك:جزء في المصدر
  form_text TEXT NOT NULL, pos_tag TEXT NOT NULL, features_raw TEXT NOT NULL,
  is_stem INTEGER NOT NULL DEFAULT 0, lemma_id INTEGER REFERENCES lexical_entries(id),
  root_id INTEGER REFERENCES roots(id), align_status TEXT NOT NULL,  -- exact | straddle
  analysis_rank INTEGER NOT NULL DEFAULT 1, source_id INTEGER REFERENCES source_versions(id),
  confidence TEXT NOT NULL DEFAULT 'inherited', review_status TEXT NOT NULL DEFAULT 'unreviewed',
  UNIQUE(word_id, seg_index, analysis_rank)
);
CREATE INDEX IF NOT EXISTS idx_morph_word ON morph_analyses(word_id);
CREATE INDEX IF NOT EXISTS idx_morph_lemma ON morph_analyses(lemma_id);
CREATE INDEX IF NOT EXISTS idx_morph_root ON morph_analyses(root_id);

CREATE TABLE IF NOT EXISTS word_roots(word_id INTEGER NOT NULL REFERENCES words(id), root_id INTEGER NOT NULL REFERENCES roots(id), PRIMARY KEY(word_id, root_id));
CREATE INDEX IF NOT EXISTS idx_wroots_root ON word_roots(root_id);
CREATE TABLE IF NOT EXISTS word_lemmas(word_id INTEGER NOT NULL REFERENCES words(id), lemma_id INTEGER NOT NULL REFERENCES lexical_entries(id), PRIMARY KEY(word_id, lemma_id));
CREATE INDEX IF NOT EXISTS idx_wlem_lemma ON word_lemmas(lemma_id);

-- مداخل الألفاظ (صيغة حرفية / مطبّعة) مع التكرارات
CREATE TABLE IF NOT EXISTS word_forms(
  id INTEGER PRIMARY KEY, level TEXT NOT NULL CHECK(level IN('literal','normalized')), form TEXT NOT NULL,
  word_count INTEGER NOT NULL, verse_count INTEGER NOT NULL, UNIQUE(level, form)
);
CREATE TABLE IF NOT EXISTS word_form_map(word_id INTEGER NOT NULL REFERENCES words(id), form_id INTEGER NOT NULL REFERENCES word_forms(id), PRIMARY KEY(word_id, form_id));
CREATE INDEX IF NOT EXISTS idx_wfm_form ON word_form_map(form_id);

-- الموضوعات
CREATE TABLE IF NOT EXISTS topics(
  id INTEGER PRIMARY KEY, slug TEXT NOT NULL UNIQUE, name_ar TEXT NOT NULL, parent_id INTEGER REFERENCES topics(id),
  kind TEXT NOT NULL DEFAULT 'concept', description TEXT, origin TEXT NOT NULL DEFAULT 'seed',
  status TEXT NOT NULL DEFAULT 'proposed'
);
CREATE TABLE IF NOT EXISTS topic_relations(
  id INTEGER PRIMARY KEY, topic_a INTEGER NOT NULL REFERENCES topics(id), topic_b INTEGER NOT NULL REFERENCES topics(id),
  rel_type TEXT NOT NULL, evidence TEXT, origin TEXT NOT NULL DEFAULT 'seed', UNIQUE(topic_a, topic_b, rel_type)
);
CREATE TABLE IF NOT EXISTS verse_topics(
  id INTEGER PRIMARY KEY, verse_id INTEGER NOT NULL REFERENCES verses(id), topic_id INTEGER NOT NULL REFERENCES topics(id),
  role TEXT NOT NULL DEFAULT 'secondary' CHECK(role IN('primary','secondary')),
  relevance TEXT NOT NULL CHECK(relevance IN('direct','substantive_indirect','contextual')),
  rationale TEXT, evidence_word_ids TEXT, method TEXT NOT NULL, confidence REAL NOT NULL,
  review_status TEXT NOT NULL DEFAULT 'unreviewed' CHECK(review_status IN('unreviewed','human_confirmed','rejected','disputed')),
  machine_generated INTEGER NOT NULL DEFAULT 1, run_id INTEGER, created_at TEXT NOT NULL,
  UNIQUE(verse_id, topic_id, method)
);
CREATE INDEX IF NOT EXISTS idx_vt_topic ON verse_topics(topic_id);
CREATE INDEX IF NOT EXISTS idx_vt_verse ON verse_topics(verse_id);
CREATE TABLE IF NOT EXISTS word_topic_links(
  word_id INTEGER NOT NULL REFERENCES words(id), topic_id INTEGER NOT NULL REFERENCES topics(id),
  verse_topic_id INTEGER NOT NULL REFERENCES verse_topics(id) ON DELETE CASCADE, is_cue INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(word_id, verse_topic_id)
);
CREATE INDEX IF NOT EXISTS idx_wtl_topic ON word_topic_links(topic_id);

-- الاجتهاد التفسيري (لا تُدرج مراجع غير موثّقة)
CREATE TABLE IF NOT EXISTS tafsir_sources(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, author TEXT, edition TEXT, url TEXT, license TEXT);
CREATE TABLE IF NOT EXISTS tafsir_refs(
  id INTEGER PRIMARY KEY, verse_id INTEGER NOT NULL REFERENCES verses(id), source_id INTEGER NOT NULL REFERENCES tafsir_sources(id),
  topic_id INTEGER REFERENCES topics(id), locator TEXT NOT NULL, stance TEXT NOT NULL DEFAULT 'supports', note TEXT
);
CREATE TABLE IF NOT EXISTS evidence_notes(
  id INTEGER PRIMARY KEY, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, note TEXT NOT NULL,
  author TEXT, created_at TEXT NOT NULL
);

-- المرادفات والعلاقات الدلالية: مستقلة عن الجذور ولا تُدمج معها تلقائيًا
CREATE TABLE IF NOT EXISTS semantic_groups(id INTEGER PRIMARY KEY, label TEXT NOT NULL UNIQUE, note TEXT, origin TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'unreviewed');
CREATE TABLE IF NOT EXISTS semantic_members(group_id INTEGER NOT NULL REFERENCES semantic_groups(id), root_id INTEGER NOT NULL REFERENCES roots(id), PRIMARY KEY(group_id, root_id));

-- نتائج الذكاء الاصطناعي مخزّنة مع مزوّدها وإصدار الأمر (لا استدعاء عند الاستعلام)
CREATE TABLE IF NOT EXISTS ai_cache(
  id INTEGER PRIMARY KEY, provider TEXT NOT NULL, model TEXT, prompt_hash TEXT NOT NULL, unit TEXT NOT NULL,
  response TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(provider, prompt_hash, unit)
);

-- فهرس التقاطعات المحسوب مسبقًا: (نوع المفتاح، المفتاح، موضوع، مستوى الصلة) → عدد الآيات المشتركة. صلة «سياقية» لا تدخل.
CREATE TABLE IF NOT EXISTS intersection_index(
  kind TEXT NOT NULL CHECK(kind IN('form','lemma','root')), key TEXT NOT NULL, topic_id INTEGER NOT NULL REFERENCES topics(id),
  relevance TEXT NOT NULL, verse_count INTEGER NOT NULL, PRIMARY KEY(kind, key, topic_id, relevance)
);
CREATE INDEX IF NOT EXISTS idx_ix_topic ON intersection_index(topic_id);

CREATE TABLE IF NOT EXISTS review_log(
  id INTEGER PRIMARY KEY, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, old_value TEXT, new_value TEXT,
  reviewer TEXT, note TEXT, ts TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS runs(
  id INTEGER PRIMARY KEY, stage TEXT NOT NULL, started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL,
  params TEXT, stats TEXT
);
CREATE TABLE IF NOT EXISTS error_log(
  id INTEGER PRIMARY KEY, run_id INTEGER, stage TEXT NOT NULL, severity TEXT NOT NULL,   -- error | unresolved | warning
  ref TEXT, message TEXT NOT NULL, ts TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS stage_state(
  stage TEXT PRIMARY KEY, input_hash TEXT NOT NULL, status TEXT NOT NULL, finished_at TEXT, stats TEXT
);
CREATE TABLE IF NOT EXISTS stage_progress(
  stage TEXT NOT NULL, unit TEXT NOT NULL, done_at TEXT NOT NULL, PRIMARY KEY(stage, unit)
);

-- حماية النص الأصلي من أي تعديل أو حذف بعد الاستيراد
CREATE TRIGGER IF NOT EXISTS verses_no_update BEFORE UPDATE ON verses BEGIN SELECT RAISE(ABORT,'النص القرآني الأصلي لا يُعدَّل'); END;
CREATE TRIGGER IF NOT EXISTS verses_no_delete BEFORE DELETE ON verses BEGIN SELECT RAISE(ABORT,'النص القرآني الأصلي لا يُحذف'); END;
CREATE TRIGGER IF NOT EXISTS words_no_update BEFORE UPDATE ON words BEGIN SELECT RAISE(ABORT,'النص القرآني الأصلي لا يُعدَّل'); END;
CREATE TRIGGER IF NOT EXISTS words_no_delete BEFORE DELETE ON words BEGIN SELECT RAISE(ABORT,'النص القرآني الأصلي لا يُحذف'); END;
"""


def connect(path=None, readonly: bool = False) -> sqlite3.Connection:
    path = path or config.DB_PATH
    if readonly:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    else:
        config.OUTPUT.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    if not readonly:
        con.execute("PRAGMA journal_mode=WAL")
    return con


def _migrate(con: sqlite3.Connection) -> None:
    cols = {r[1] for r in con.execute("PRAGMA table_info(word_search)")}
    if cols and "text_nfd" not in cols:
        con.execute("ALTER TABLE word_search ADD COLUMN text_nfd TEXT")
    con.execute("CREATE INDEX IF NOT EXISTS idx_wsearch_nfd ON word_search(text_nfd)")


def init_schema(con: sqlite3.Connection) -> None:
    con.executescript(SCHEMA)
    _migrate(con)
    con.commit()


@contextmanager
def tx(con: sqlite3.Connection):
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
