"""فحوص التحقق الآلي (مستقلة عن منطق البناء قدر الإمكان: تعيد الحساب من الملفات الخام).

تُنتج قائمة نتائج: (الاسم، نجح؟، تفصيل). تُستعمل في الاختبارات وفي التقرير النهائي.
هذه الفحوص تثبت سلامة *البرمجة* والبيانات المستوردة، ولا تثبت صحة التحليل الصرفي أو الموضوعي علميًا.
"""
from __future__ import annotations
import json, collections
from . import config, search, intersect
from .importer import load_text, load_morph
from .textnorm import normalize_v1, skeleton
from .util import sha256_text
from .sources import verify_raw_files


def _chk(name, ok, detail=""):
    return {"name": name, "ok": bool(ok), "detail": detail}


def run_all(con) -> list[dict]:
    res = []
    q1 = lambda sql, *a: con.execute(sql, a).fetchone()[0]
    raw = load_text()
    # 1 بصمات المصادر
    try:
        verify_raw_files(); res.append(_chk("بصمات الملفات الخام مطابقة للمسجّلة", True))
    except AssertionError as e:
        res.append(_chk("بصمات الملفات الخام مطابقة للمسجّلة", False, str(e)))
    # 2 اكتمال السور والآيات
    chap = {r["id"]: r["verse_count"] for r in con.execute("SELECT id, verse_count FROM chapters")}
    got = {r["surah"]: r["n"] for r in con.execute("SELECT surah, COUNT(*) n FROM verses GROUP BY surah")}
    res.append(_chk("114 سورة", len(chap) == 114 and len(got) == 114, f"{len(chap)}/{len(got)}"))
    res.append(_chk("عدد آيات كل سورة = بيانات السور", chap == got, "" if chap == got else str({k: (chap[k], got.get(k)) for k in chap if chap[k] != got.get(k)})))
    res.append(_chk("مجموع الآيات 6236", q1("SELECT COUNT(*) FROM verses") == config.EXPECTED_VERSES, str(q1("SELECT COUNT(*) FROM verses"))))
    # 3 صحة الأرقام: تتابع 1..n دون ثغرات
    gaps = [s for s in got if q1("SELECT MAX(ayah)-MIN(ayah)+1-COUNT(*) FROM verses WHERE surah=?", s) != 0 or q1("SELECT MIN(ayah) FROM verses WHERE surah=?", s) != 1]
    res.append(_chk("ترقيم الآيات متتابع بلا ثغرات", not gaps, str(gaps)))
    bad_id = q1("SELECT COUNT(*) FROM verses WHERE id != surah*1000+ayah") + q1("SELECT COUNT(*) FROM words WHERE id != (verse_id/1000)*1000000 + (verse_id%1000)*1000 + pos")
    res.append(_chk("المعرفات الثابتة متسقة مع (سورة، آية، موضع)", bad_id == 0, str(bad_id)))
    # 4 النص الأصلي لم يتغيّر حرفًا
    diff = 0
    for r in con.execute("SELECT surah, ayah, text_original, text_sha256 FROM verses"):
        orig = next(x["text"] for x in raw[r["surah"]] if x["verse"] == r["ayah"]) if False else None
    rawmap = {(s, v["verse"]): v["text"] for s, vs in raw.items() for v in vs}
    for r in con.execute("SELECT surah, ayah, text_original, text_sha256 FROM verses"):
        if rawmap[(r["surah"], r["ayah"])] != r["text_original"] or sha256_text(r["text_original"]) != r["text_sha256"]:
            diff += 1
    res.append(_chk("النص الأصلي مطابق حرفيًا للملف الخام (6236 آية) وبصمة كل آية سليمة", diff == 0, f"آيات مختلفة: {diff}"))
    # 5 كلمات الآية = الآية بعد فصل البسملة المسبوقة
    bad = 0
    for r in con.execute("SELECT id, text_original, basmalah_prefix_words, word_count FROM verses"):
        ws = [x[0] for x in con.execute("SELECT text_original FROM words WHERE verse_id=? ORDER BY pos", (r["id"],))]
        toks = r["text_original"].split(" ")[r["basmalah_prefix_words"]:]
        if ws != toks or len(ws) != r["word_count"]:
            bad += 1
    res.append(_chk("كلمات كل آية تعيد بناء نصها الأصلي (بعد فصل البسملة المسبوقة) دون فقد", bad == 0, f"آيات مختلفة: {bad}"))
    # 6 الفصل بين الأصلي والمطبّع
    trig = 0
    for sql in ("UPDATE verses SET text_original='x' WHERE id=1001", "UPDATE words SET text_original='x' WHERE id=1001001", "DELETE FROM words WHERE id=1001001"):
        try:
            con.execute(sql); con.rollback(); trig += 1
        except Exception:
            con.rollback()
    res.append(_chk("مشغّلات منع تعديل/حذف النص الأصلي فعّالة", trig == 0, f"عمليات نفذت خطأً: {trig}"))
    same = q1("SELECT COUNT(*) FROM word_search ws JOIN words w ON w.id=ws.word_id WHERE ws.text_norm=w.text_original")
    cols = [r[1] for r in con.execute("PRAGMA table_info(words)")]
    res.append(_chk("النسخة المطبّعة في جدول مستقل ولا عمود مطبّع في جدول النص الأصلي", "text_norm" not in cols,
                    f"كلمات لم يغيّرها التطبيع أصلًا (بلا تشكيل): {same}"))
    # 7 لا فقدان مواضع بسبب التشكيل
    miss = q1("SELECT COUNT(*) FROM words w LEFT JOIN word_search ws ON ws.word_id=w.id WHERE ws.word_id IS NULL OR ws.text_norm=''")
    res.append(_chk("لكل كلمة صيغة مطبّعة غير فارغة (لا مواضع مفقودة بسبب التشكيل)", miss == 0, str(miss)))
    recomputed = sum(1 for r in con.execute("SELECT w.text_original o, ws.text_norm n FROM words w JOIN word_search ws ON ws.word_id=w.id") if normalize_v1(r["o"]) != r["n"])
    res.append(_chk("الصيغ المطبّعة المخزّنة = إعادة حساب دالة التطبيع", recomputed == 0, str(recomputed)))
    # التمثيل الرقمي للحروف: مفتاح NFD المخزّن يساوي NFD لكل تمثيل (أصلي/NFC/NFD) لكل كلمة، فلا يضيع موضع
    import unicodedata, random
    bad_key = n = 0
    for r in con.execute("SELECT w.text_original o, ws.text_nfd k FROM words w JOIN word_search ws ON ws.word_id=w.id"):
        n += 1
        o = r["o"]
        if not (r["k"] == unicodedata.normalize("NFD", o) == unicodedata.normalize("NFD", unicodedata.normalize("NFC", o))):
            bad_key += 1
    res.append(_chk("مفتاح التكافؤ القانوني (NFD) صحيح لكل الكلمات (%d) ويطابق تمثيلات NFC/NFD" % n, bad_key == 0, f"كلمات مختلفة: {bad_key}"))
    forms = [r[0] for r in con.execute("SELECT DISTINCT text_original FROM words")]
    random.Random(7).shuffle(forms)
    lost = 0
    for f in forms[:600]:
        want = {r[0] for r in con.execute("SELECT id FROM words WHERE text_original=?", (f,))}
        for variant in (f, unicodedata.normalize("NFC", f), unicodedata.normalize("NFD", f)):
            if not want <= {x["word_id"] for x in search.literal(con, variant)}:
                lost += 1; break
    res.append(_chk("البحث الحرفي (عيّنة ثابتة 600 صيغة × 3 تمثيلات) يسترجع كل مواضع الصيغة", lost == 0, f"صيغ ضائعة: {lost}"))
    # 8 التكرارات
    cnt = collections.Counter(w for ws in ((x["text"].split(" ")[(4 if (s not in (1, 9) and x["verse"] == 1) else 0):]) for s, vs in raw.items() for x in vs) for w in ws)
    db_lit = {r["form"]: r["word_count"] for r in con.execute("SELECT form, word_count FROM word_forms WHERE level='literal'")}
    res.append(_chk("تكرارات الصيغ الحرفية = إعادة العدّ من الملف الخام", dict(cnt) == db_lit, f"{len(cnt)} صيغة"))
    tot_l = q1("SELECT SUM(word_count) FROM word_forms WHERE level='literal'"); tot_n = q1("SELECT SUM(word_count) FROM word_forms WHERE level='normalized'")
    res.append(_chk("مجموع التكرارات = عدد الكلمات (حرفي ومطبّع)", tot_l == tot_n == q1("SELECT COUNT(*) FROM words"), f"{tot_l}/{tot_n}"))
    vbad = q1("SELECT COUNT(*) FROM word_forms f WHERE verse_count > word_count")
    res.append(_chk("عدد الآيات لكل صيغة ≤ عدد التكرارات", vbad == 0, str(vbad)))
    # 9 الجذور من الملف الخام
    morph = load_morph()
    root_words = collections.defaultdict(set)
    for (s, a), segs in morph.items():
        for (w, g, form, tag, feat) in segs:
            for f in feat.split("|"):
                if f.startswith("ROOT:"):
                    root_words[f[5:]].add((s, a, w))
    db_roots = {r["root"]: r["word_count"] for r in con.execute("SELECT root, word_count FROM roots")}
    d = {k: (len(v), db_roots.get(k)) for k, v in root_words.items() if len(v) != db_roots.get(k)}
    res.append(_chk("عدد كلمات كل جذر = إعادة العدّ من ملف الصرف الخام (تفاوت مسموح ≤1 عند فروق التقطيع)", all(abs(a - (b or 0)) <= 1 for a, b in d.values()) and len(db_roots) == len(root_words), f"فروق: {d}"))
    orphan = q1("""SELECT COUNT(*) FROM word_roots wr WHERE NOT EXISTS (SELECT 1 FROM morph_analyses m WHERE m.word_id=wr.word_id AND m.root_id=wr.root_id)""")
    res.append(_chk("كل رابط كلمة-جذر مسنود بجزء صرفي يحمل الجذر", orphan == 0, str(orphan)))
    segs_raw = sum(len(v) for v in morph.values())
    res.append(_chk("كل الأجزاء الصرفية في الملف الخام مستوردة", q1("SELECT COUNT(*) FROM morph_analyses") == segs_raw, f"{q1('SELECT COUNT(*) FROM morph_analyses')}/{segs_raw}"))
    # 10 المرادفات خارج المطابقات الحرفية
    sem_in_lit = 0
    for qy in ("خوف", "هلك", "قلب"):
        lit_ids = {r["word_id"] for lvl in ("literal", "normalized", "morphological", "derivational") for r in search.search(con, qy, lvl)}
        sem_in_lit += sum(1 for r in search.semantic(con, qy) if r["word_id"] in lit_ids)
    res.append(_chk("نتائج المرادفات لا تتداخل مع نتائج المستويات اللفظية/الاشتقاقية للاستعلام", sem_in_lit == 0, str(sem_in_lit)))
    # 11 التقاطع لا يُدرج دون الشرطين
    probs = 0; nrows = 0
    for qy, tp in (("مُوسَىٰ", "f_musa_harun"), ("صَلَوٰةَ", "salah"), ("رحم", "akhirah"), ("أمن", "g_mumin")):
        r = intersect.intersect(con, qy, tp, relevance="all")
        lex = {x["verse_id"] for lvl in ("literal", "normalized", "morphological", "derivational") for x in search.search(con, qy, lvl)}
        th = {x["verse_id"] for x in intersect.topic_rows(con, tp, True, "all")}
        for row in r["intersection"]:
            nrows += 1
            if row["verse_id"] not in lex or row["verse_id"] not in th or not row["words"] or not row["topic_assignments"]:
                probs += 1
        ids = [x["verse_id"] for x in r["intersection"]]
        if len(ids) != len(set(ids)) or ids != sorted(ids):
            probs += 1
    res.append(_chk("كل آية في التقاطع تحقق الشرطين (لفظ+موضوع) دون تكرار وبترتيب المصحف", probs == 0 and nrows > 0, f"صفوف مفحوصة {nrows}"))
    # 12 المعالجة على دفعات لا تُفقد آيات: أي تقسيم بحسب السورة يعيد 6236
    parts = sum(q1("SELECT COUNT(*) FROM verses WHERE surah=?", s) for s in range(1, 115))
    res.append(_chk("تقسيم المعالجة إلى دفعات (سورة سورة) يجمع 6236 آية دون فقد", parts == 6236, str(parts)))
    # 13 إسنادات الموضوع سليمة
    badvt = q1("SELECT COUNT(*) FROM verse_topics WHERE verse_id NOT IN (SELECT id FROM verses) OR confidence<0 OR confidence>1")
    res.append(_chk("إسنادات الموضوعات: آيات صحيحة وثقة ضمن [0,1]", badvt == 0, str(badvt)))
    unlabeled = q1("SELECT COUNT(*) FROM verse_topics WHERE machine_generated=1 AND review_status='human_confirmed'")
    res.append(_chk("لا إسناد آلي يُوسَم «مؤكَّد بشريًا» دون سجل مراجعة", unlabeled == q1("SELECT COUNT(DISTINCT entity_id) FROM review_log WHERE entity_type='verse_topic' AND new_value='human_confirmed'") if unlabeled else True, str(unlabeled)))
    return res
