"""بناء الفهارس اللفظية والجذرية وحساب التكرارات من البيانات المستوردة (لا أرقام تقديرية)."""
from __future__ import annotations
from . import db


def run(con, run_id=None) -> dict:
    with db.tx(con):
        con.execute("DELETE FROM word_form_map"); con.execute("DELETE FROM word_forms")
        # صيغ حرفية: النص الأصلي كما هو
        con.execute("""INSERT INTO word_forms(level,form,word_count,verse_count)
                       SELECT 'literal', text_original, COUNT(*), COUNT(DISTINCT verse_id) FROM words GROUP BY text_original""")
        con.execute("""INSERT INTO word_forms(level,form,word_count,verse_count)
                       SELECT 'normalized', ws.text_norm, COUNT(*), COUNT(DISTINCT w.verse_id)
                       FROM word_search ws JOIN words w ON w.id=ws.word_id GROUP BY ws.text_norm""")
        con.execute("""INSERT INTO word_form_map SELECT w.id, f.id FROM words w JOIN word_forms f ON f.level='literal' AND f.form=w.text_original""")
        con.execute("""INSERT INTO word_form_map SELECT ws.word_id, f.id FROM word_search ws JOIN word_forms f ON f.level='normalized' AND f.form=ws.text_norm""")
        # جذور
        con.execute("""UPDATE roots SET
            word_count=(SELECT COUNT(*) FROM word_roots wr WHERE wr.root_id=roots.id),
            verse_count=(SELECT COUNT(DISTINCT w.verse_id) FROM word_roots wr JOIN words w ON w.id=wr.word_id WHERE wr.root_id=roots.id)""")
        con.execute("""UPDATE lexical_entries SET
            word_count=(SELECT COUNT(*) FROM word_lemmas wl WHERE wl.lemma_id=lexical_entries.id),
            verse_count=(SELECT COUNT(DISTINCT w.verse_id) FROM word_lemmas wl JOIN words w ON w.id=wl.word_id WHERE wl.lemma_id=lexical_entries.id)""")
    q = lambda sql: con.execute(sql).fetchone()[0]
    return dict(
        literal_forms=q("SELECT COUNT(*) FROM word_forms WHERE level='literal'"),
        normalized_forms=q("SELECT COUNT(*) FROM word_forms WHERE level='normalized'"),
        roots_with_words=q("SELECT COUNT(*) FROM roots WHERE word_count>0"),
        lemmas_with_words=q("SELECT COUNT(*) FROM lexical_entries WHERE word_count>0"),
        word_root_links=q("SELECT COUNT(*) FROM word_roots"),
        word_lemma_links=q("SELECT COUNT(*) FROM word_lemmas"),
    )
