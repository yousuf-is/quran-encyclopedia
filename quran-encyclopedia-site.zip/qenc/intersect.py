"""محرك التقاطع بين مجموعة لفظية ومجموعة موضوعية.

لا تُدرج آية إلا إذا تحقق الشرطان معًا: (١) فيها لفظ مطابق للاستعلام على مستوى مسموح، (٢) مسندة إلى الموضوع
(أو أحد فروعه) بمستوى صلة مسموح وحالة مراجعة غير «مرفوضة».

فئات النتيجة:
  أ  اللفظ نفسه (حرفيًا أو بعد التطبيع) في آية تتناول الموضوع مباشرة.
  ب  صيغة صرفية/مشتق (لمّة أو جذر) في آية تتناول الموضوع مباشرة.
  ج  اللفظ أو الصيغة المسموح بها في آية تتناول الموضوع تناولًا جوهريًا غير مباشر
     (وتُضاف «سياقية» فقط إن طُلبت صراحةً، وتُوسَم).
  د  مرادف/مجموعة دلالية: مجموعة منفصلة تمامًا لا تُدمج مع أ/ب/ج.
"""
from __future__ import annotations
import json
from . import search

LEVEL_ORDER = {"literal": 0, "normalized": 1, "morphological": 2, "derivational": 3}
REL_ALLOWED = {"direct": ("direct",), "indirect": ("direct", "substantive_indirect"), "all": ("direct", "substantive_indirect", "contextual")}


def topic_ids(con, slug: str, descendants: bool = True) -> list[int]:
    row = con.execute("SELECT id FROM topics WHERE slug=?", (slug,)).fetchone()
    if not row:
        raise KeyError(f"موضوع غير معروف: {slug}")
    ids = [row[0]]
    if descendants:
        frontier = [row[0]]
        while frontier:
            q = ",".join("?" * len(frontier))
            frontier = [r[0] for r in con.execute(f"SELECT id FROM topics WHERE parent_id IN ({q})", frontier)]
            ids += frontier
    return ids


def topic_rows(con, slug: str, descendants=True, relevance="indirect", include_rejected=False):
    ids = topic_ids(con, slug, descendants)
    q = ",".join("?" * len(ids))
    allowed = REL_ALLOWED[relevance]
    qa = ",".join("?" * len(allowed))
    sql = f"""SELECT vt.id AS vt_id, vt.verse_id, vt.topic_id, t.slug, t.name_ar, vt.role, vt.relevance, vt.rationale, vt.method, vt.confidence,
                     vt.review_status, vt.machine_generated, vt.evidence_word_ids
              FROM verse_topics vt JOIN topics t ON t.id=vt.topic_id
              WHERE vt.topic_id IN ({q}) AND vt.relevance IN ({qa})""" + ("" if include_rejected else " AND vt.review_status!='rejected'") + " ORDER BY vt.verse_id"
    return [dict(r) for r in con.execute(sql, [*ids, *allowed])]


def topic_verses(con, slug, descendants=True, relevance="indirect", include_rejected=False):
    """الموضوع ← جميع الآيات (بلا تكرار، بترتيب المصحف) مع إسناداتها."""
    by = {}
    for r in topic_rows(con, slug, descendants, relevance, include_rejected):
        by.setdefault(r["verse_id"], []).append(r)
    out = []
    for vid in sorted(by):
        v = con.execute("SELECT v.surah, v.ayah, v.text_original, c.name_ar FROM verses v JOIN chapters c ON c.id=v.surah WHERE v.id=?", (vid,)).fetchone()
        out.append({"verse_id": vid, "surah": v[0], "ayah": v[1], "verse_text": v[2], "surah_name": v[3], "assignments": by[vid]})
    return out


def _is_disputed(assigns):
    st = {a["review_status"] for a in assigns}
    return "disputed" in st or ({"human_confirmed", "rejected"} <= st)


def intersect(con, query: str, topic: str, max_level: str = "derivational", descendants: bool = True,
              relevance: str = "indirect", include_synonyms: bool = True, include_rejected: bool = False):
    if max_level not in LEVEL_ORDER:
        raise ValueError("max_level يجب أن يكون literal|normalized|morphological|derivational")
    lim = LEVEL_ORDER[max_level]
    # المجموعة اللفظية: لكل آية أقوى مستوى مطابقة + الكلمات
    lex = {}
    for lvl in ("literal", "normalized", "morphological", "derivational"):
        if LEVEL_ORDER[lvl] > lim:
            break
        for r in search.search(con, query, lvl):
            e = lex.setdefault(r["verse_id"], {"words": {}, "best": lvl})
            e["words"].setdefault(r["word_id"], {"pos": r["pos"], "text": r["text_original"], "level": lvl, "reason": r["reason"]})
    th = {}
    for r in topic_rows(con, topic, descendants, relevance, include_rejected):
        th.setdefault(r["verse_id"], []).append(r)
    rows = []
    for vid in sorted(set(lex) & set(th)):
        words = sorted(lex[vid]["words"].values(), key=lambda w: w["pos"])
        best = lex[vid]["best"]
        assigns = th[vid]
        direct = any(a["relevance"] == "direct" for a in assigns)
        indirect = any(a["relevance"] == "substantive_indirect" for a in assigns)
        same_word = best in ("literal", "normalized")
        if direct:
            cat = "أ" if same_word else "ب"
        elif indirect:
            cat = "ج"
        else:
            cat = "ج (سياقية)"
        v = con.execute("SELECT v.surah, v.ayah, v.text_original, c.name_ar FROM verses v JOIN chapters c ON c.id=v.surah WHERE v.id=?", (vid,)).fetchone()
        rows.append({"category": cat, "verse_id": vid, "surah": v[0], "ayah": v[1], "surah_name": v[3], "verse_text": v[2],
                     "words": words, "lexical_level": best, "topic_assignments": assigns, "disputed": _is_disputed(assigns),
                     "why": f"لفظ ({best}): " + "، ".join(f"{w['text']}@{w['pos']}" for w in words) + " + موضوع: " +
                            "؛ ".join(sorted({f"{a['name_ar']} [{a['relevance']}/{a['method']}/{a['review_status']}]" for a in assigns}))})
    syn = []
    if include_synonyms:
        main = {r["verse_id"] for r in rows}
        sem = {}
        for r in search.semantic(con, query):
            sem.setdefault(r["verse_id"], []).append(r)
        for vid in sorted(set(sem) & set(th)):
            if any(a["relevance"] == "contextual" for a in th[vid]) and not any(a["relevance"] != "contextual" for a in th[vid]) and relevance != "all":
                continue
            v = con.execute("SELECT v.surah, v.ayah, v.text_original, c.name_ar FROM verses v JOIN chapters c ON c.id=v.surah WHERE v.id=?", (vid,)).fetchone()
            syn.append({"category": "د", "verse_id": vid, "surah": v[0], "ayah": v[1], "surah_name": v[3], "verse_text": v[2],
                        "words": [{"pos": w["pos"], "text": w["text_original"], "group": w["group"], "roots": w["roots"]} for w in sem[vid]],
                        "topic_assignments": th[vid], "also_in_lexical_set": vid in main, "disputed": _is_disputed(th[vid]),
                        "why": "مجموعة دلالية منفصلة: " + "، ".join(sorted({w["group"] for w in sem[vid]}))})
    counts = {k: sum(1 for r in rows if r["category"].startswith(k)) for k in ("أ", "ب", "ج")}
    counts["د"] = len(syn)
    return {"query": query, "topic": topic, "max_level": max_level, "descendants": descendants, "relevance": relevance,
            "lexical_verses": len(lex), "topic_verses": len(th), "intersection": rows, "synonym_set": syn, "counts": counts}


def build_index(con) -> dict:
    """يبني فهرس التقاطعات (صيغة مطبّعة / لمّة / جذر × موضوع) من البيانات المفهرسة؛ بلا ذكاء اصطناعي."""
    from . import db
    with db.tx(con):
        con.execute("DELETE FROM intersection_index")
        base = """FROM verse_topics vt JOIN words w ON w.verse_id=vt.verse_id %s
                  WHERE vt.review_status!='rejected' AND vt.relevance IN ('direct','substantive_indirect') GROUP BY 1,2,3,4"""
        con.execute("INSERT INTO intersection_index SELECT 'root', r.root, vt.topic_id, vt.relevance, COUNT(DISTINCT vt.verse_id) " + base % "JOIN word_roots wr ON wr.word_id=w.id JOIN roots r ON r.id=wr.root_id")
        con.execute("INSERT INTO intersection_index SELECT 'lemma', le.lemma || ' / ' || COALESCE(le.pos,''), vt.topic_id, vt.relevance, COUNT(DISTINCT vt.verse_id) " + base % "JOIN word_lemmas wl ON wl.word_id=w.id JOIN lexical_entries le ON le.id=wl.lemma_id")
        con.execute("INSERT INTO intersection_index SELECT 'form', ws.text_norm, vt.topic_id, vt.relevance, COUNT(DISTINCT vt.verse_id) " + base % "JOIN word_search ws ON ws.word_id=w.id")
    return {k: con.execute("SELECT COUNT(*) FROM intersection_index WHERE kind=?", (k,)).fetchone()[0] for k in ("root", "lemma", "form")}
