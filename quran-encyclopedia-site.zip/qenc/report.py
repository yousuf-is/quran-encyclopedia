"""التقرير النهائي (عربي، RTL): كل رقم محسوب من قاعدة البيانات لحظة التوليد — لا تقديرات."""
from __future__ import annotations
import html, json
from . import config, verify, export
from .util import now


def gather(con) -> dict:
    q1 = lambda sql, *a: con.execute(sql, a).fetchone()[0]
    qa = lambda sql, *a: [dict(r) for r in con.execute(sql, a)]
    d = {"generated_at": now()}
    d["counts"] = dict(
        surahs=q1("SELECT COUNT(*) FROM chapters"), verses=q1("SELECT COUNT(*) FROM verses"), words=q1("SELECT COUNT(*) FROM words"),
        literal_forms=q1("SELECT COUNT(*) FROM word_forms WHERE level='literal'"), normalized_forms=q1("SELECT COUNT(*) FROM word_forms WHERE level='normalized'"),
        morph_segments=q1("SELECT COUNT(*) FROM morph_analyses"), words_with_analysis=q1("SELECT COUNT(DISTINCT word_id) FROM morph_analyses"),
        roots=q1("SELECT COUNT(*) FROM roots"), lemmas=q1("SELECT COUNT(*) FROM lexical_entries"),
        word_root_links=q1("SELECT COUNT(*) FROM word_roots"), topics=q1("SELECT COUNT(*) FROM topics"),
        topic_relations=q1("SELECT COUNT(*) FROM topic_relations"), semantic_groups=q1("SELECT COUNT(*) FROM semantic_groups"),
        verse_topic_rows=q1("SELECT COUNT(*) FROM verse_topics"), word_topic_links=q1("SELECT COUNT(*) FROM word_topic_links"),
        intersection_index_rows=q1("SELECT COUNT(*) FROM intersection_index"), tafsir_refs=q1("SELECT COUNT(*) FROM tafsir_refs"),
    )
    d["align"] = qa("SELECT align_status, COUNT(*) n FROM morph_analyses GROUP BY 1")
    d["sources"] = qa("SELECT name, role, version, sha256, bytes, license_status, license, attribution, notes, imported_at FROM source_versions ORDER BY id")
    d["by_method"] = qa("""SELECT method, relevance, review_status, COUNT(*) n, COUNT(DISTINCT verse_id) verses FROM verse_topics GROUP BY 1,2,3 ORDER BY 1,2""")
    d["coverage"] = dict(
        any=q1("SELECT COUNT(DISTINCT verse_id) FROM verse_topics WHERE review_status!='rejected'"),
        non_contextual=q1("SELECT COUNT(DISTINCT verse_id) FROM verse_topics WHERE relevance!='contextual' AND review_status!='rejected'"),
        direct=q1("SELECT COUNT(DISTINCT verse_id) FROM verse_topics WHERE relevance='direct' AND review_status!='rejected'"),
        non_lexical_non_contextual=q1("SELECT COUNT(DISTINCT verse_id) FROM verse_topics WHERE relevance!='contextual' AND method!='lexical_rule' AND review_status!='rejected'"),
        human_confirmed=q1("SELECT COUNT(*) FROM verse_topics WHERE review_status='human_confirmed'"),
        ai_rows=q1("SELECT COUNT(*) FROM verse_topics WHERE method LIKE 'ai:%'"),
    )
    d["by_category"] = qa("""SELECT t.name_ar AS category, COUNT(DISTINCT vt.verse_id) verses
        FROM topics t JOIN topics c ON (c.id=t.id OR c.parent_id=t.id) JOIN verse_topics vt ON vt.topic_id=c.id
        WHERE t.parent_id IS NULL AND vt.relevance!='contextual' AND vt.review_status!='rejected' GROUP BY t.id ORDER BY t.id""")
    d["issues"] = qa("SELECT stage, severity, ref, message FROM error_log ORDER BY id")
    d["checks"] = verify.run_all(con)
    d["surahs_without_noncontextual_topic"] = [r["id"] for r in qa("""SELECT c.id FROM chapters c WHERE NOT EXISTS
        (SELECT 1 FROM verse_topics vt JOIN verses v ON v.id=vt.verse_id WHERE v.surah=c.id AND vt.relevance!='contextual' AND vt.review_status!='rejected')""")]
    return d


def _tbl(rows, cols):
    h = "".join(f"<th>{html.escape(c)}</th>" for _, c in cols)
    b = "".join("<tr>" + "".join(f"<td>{html.escape(str(r.get(k, '')))}</td>" for k, _ in cols) + "</tr>" for r in rows)
    return f"<table><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table>"


def render_html(d: dict) -> str:
    c, cv = d["counts"], d["coverage"]
    n_ok = sum(x["ok"] for x in d["checks"])
    pct = lambda a: f"{100 * a / c['verses']:.1f}٪"
    s = []
    s.append(f"<h1>التقرير النهائي لتشغيل الموسوعة القرآنية</h1><p class='meta'>وُلّد في {d['generated_at']} — كل الأرقام أدناه محسوبة من قاعدة البيانات لحظة التوليد.</p>")
    s.append("<h2>١. ما عولج فعليًا</h2>" + _tbl([
        {"k": "السور", "v": c["surahs"]}, {"k": "الآيات", "v": c["verses"]}, {"k": "الكلمات (مواضع)", "v": c["words"]},
        {"k": "الصيغ الحرفية المتمايزة", "v": c["literal_forms"]}, {"k": "الصيغ المطبّعة المتمايزة", "v": c["normalized_forms"]},
        {"k": "الأجزاء الصرفية المستوردة", "v": c["morph_segments"]}, {"k": "كلمات لها تحليل صرفي مسنَد", "v": c["words_with_analysis"]},
        {"k": "الجذور", "v": c["roots"]}, {"k": "المداخل المعجمية (لمّات)", "v": c["lemmas"]}, {"k": "روابط كلمة-جذر", "v": c["word_root_links"]},
        {"k": "الموضوعات في التصنيف", "v": c["topics"]}, {"k": "علاقات بين الموضوعات (غير الأبوة)", "v": c["topic_relations"]},
        {"k": "المجموعات الدلالية", "v": c["semantic_groups"]}, {"k": "صفوف إسناد آية↔موضوع", "v": c["verse_topic_rows"]},
        {"k": "روابط كلمة↔موضوع", "v": c["word_topic_links"]}, {"k": "صفوف فهرس التقاطعات", "v": c["intersection_index_rows"]},
        {"k": "مراجع تفسيرية موثّقة", "v": c["tafsir_refs"]}], [("k", "البند"), ("v", "العدد")]))
    s.append("<h2>٢. المصادر والتراخيص</h2>" + _tbl(d["sources"], [("name", "المصدر"), ("version", "الإصدار"), ("sha256", "SHA-256"), ("license_status", "حالة الترخيص"), ("attribution", "النسبة"), ("notes", "ملاحظات")]))
    s.append("<p>تعذّر الوصول المباشر إلى tanzil.net وcorpus.quran.com من بيئة التنفيذ (محجوبان بسياسة الشبكة)، فاستُعملت نسخ وسيطة على GitHub، وسُجّل ذلك في ملاحظات كل مصدر. <b>نص الترخيص الأصلي لمدونة القرآن لم يُتحقق منه عند مصدره</b> ويجب التحقق منه قبل أي توزيع علني.</p>")
    s.append("<h2>٣. ما تحقق منه البرنامج آليًا</h2>" + f"<p>{n_ok} من {len(d['checks'])} فحصًا ناجح.</p>" +
             _tbl([{"name": x["name"], "ok": "✔ نجح" if x["ok"] else "✘ فشل", "detail": x["detail"]} for x in d["checks"]], [("name", "الفحص"), ("ok", "النتيجة"), ("detail", "تفصيل")]) +
             "<p>هذه الفحوص تثبت سلامة الاستيراد والفهرسة والعدّ والتقاطع <b>برمجيًا</b>، ولا تثبت صحة التحليل الصرفي ولا صحة التصنيف الموضوعي علميًا.</p>")
    s.append("<h2>٤. المحاذاة بين نص تنزيل والتحليل الصرفي</h2>" + _tbl(d["align"], [("align_status", "حالة المحاذاة"), ("n", "عدد الأجزاء")]) +
             "<p>exact: مطابقة هيكلية كاملة؛ by_word_index: اختلاف إملائي في آيتين فأُسند برقم الكلمة؛ straddle: جزء يمتد عبر حدّ كلمتين بسبب فرق تقطيع.</p>")
    s.append("<h2>٥. الفهرسة الموضوعية: الحدود الصادقة</h2>")
    s.append(f"<ul><li>آيات لها أي إسناد (يشمل الإشارات اللفظية الضعيفة «السياقية»): {cv['any']} ({pct(cv['any'])}).</li>"
             f"<li>آيات لها إسناد <b>مباشر أو جوهري غير مباشر</b>: {cv['non_contextual']} ({pct(cv['non_contextual'])}).</li>"
             f"<li>آيات لها إسناد مباشر: {cv['direct']} ({pct(cv['direct'])}).</li>"
             f"<li>آيات لها إسناد غير سياقي من مصدر غير قاعدة الأعلام اللفظية (منتقى/نموذج): {cv['non_lexical_non_contextual']} ({pct(cv['non_lexical_non_contextual'])}).</li>"
             f"<li>إسنادات أكّدها إنسان: {cv['human_confirmed']}. <b>لم تُراجَع أي إسنادات علميًا بعد</b>، وكلها «غير مراجَعة» وآلية الأصل.</li>"
             f"<li>صفوف مقترحات نموذج لغوي مستوردة: {cv['ai_rows']}.</li>"
             f"<li>سور بلا أي إسناد غير سياقي: {len(d['surahs_without_noncontextual_topic'])} من 114.</li></ul>")
    s.append("<p><b>التصنيف الموضوعي غير مكتمل</b>: التصنيف المستعمل مقترح أوّلي وليس القائمة النهائية لموضوعات القرآن، والإسناد لم يبلغ بعدُ معيار الإكمال المعلن (مراجعة علمية لكل آية). الإشارات اللفظية بالجذور لا تُعدّ دليلًا على الموضوع، لذلك تُصنَّف «سياقية» وتُستبعد من التقاطع افتراضيًا.</p>")
    s.append(_tbl(d["by_method"], [("method", "الطريقة"), ("relevance", "الصلة"), ("review_status", "المراجعة"), ("n", "صفوف"), ("verses", "آيات")]))
    s.append("<h3>تغطية الموضوعات الرئيسة (آيات بإسناد غير سياقي)</h3>" + _tbl(d["by_category"], [("category", "الموضوع الرئيس"), ("verses", "عدد الآيات")]))
    s.append("<h2>٦. مواضع غير محسومة وأخطاء</h2>" + (_tbl(d["issues"], [("stage", "المرحلة"), ("severity", "الخطورة"), ("ref", "الموضع"), ("message", "الرسالة")]) if d["issues"] else "<p>لا شيء.</p>"))
    s.append("<h2>٧. ما يحتاج مراجعة علمية بشرية</h2><ul>"
             "<li>كل إسنادات الموضوعات (آلية/منتقاة) وقائمة الموضوعات نفسها.</li>"
             "<li>الجذور والمداخل المعجمية في نسخة الـ fork (فيها تعديلات عن v0.4 الأصلي لم تُراجَع هنا).</li>"
             "<li>المجموعات الدلالية (المرادفات) المقترحة.</li>"
             "<li>إضافة المراجع التفسيرية الموثّقة (الجدول فارغ عمدًا لأن لا مرجع بعينه تُحقّق منه).</li>"
             "<li>الآيتان 12:39 و12:41 (اختلاف إملائي بين المصدرين) والموضع 37:130 (فرق تقطيع «إِلْ يَاسِينَ»).</li>"
             "<li>التحقق من بصمة نص تنزيل مقابل tanzil.net مباشرة، ومن ترخيص مدونة القرآن عند مصدرها.</li></ul>")
    return export.HTML_TMPL.format(title="التقرير النهائي", meta="", head="", body="").split("<h1>")[0] + "".join(s) + "</body></html>"


def run(con) -> dict:
    d = gather(con)
    config.REPORT_DIR.mkdir(parents=True, exist_ok=True)
    h = render_html(d)
    h = h.replace("<table><thead><tr></tr></thead><tbody>", "<table><thead><tr></tr></thead><tbody>")
    hp = config.REPORT_DIR / "final_report.html"
    hp.write_text(h, encoding="utf-8")
    (config.REPORT_DIR / "final_report.json").write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    pdf = export.html_to_pdf(hp, config.REPORT_DIR / "final_report.pdf")
    return {"report_html": str(hp), "report_pdf": bool(pdf), "checks_passed": sum(x["ok"] for x in d["checks"]), "checks_total": len(d["checks"]), "coverage": d["coverage"]}
