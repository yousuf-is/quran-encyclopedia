"""سجل المصادر: الإصدار والبصمة والترخيص. أي تغيّر في بصمة ملف خام يُوقف الاستيراد."""
from __future__ import annotations
from . import config
from .util import sha256_file, now

# بصمات مسجّلة وقت الاستيراد الأول (SHA-256). إن تغيّر أي ملف خام فشل التحقق.
EXPECTED_SHA256 = {
    "tanzil/uthmani.json": "adaebb377c60eba1bab6ef652959c7a0b4ccb4d0ca42145945c14ecdbeb4b761",
    "tanzil/chapters.json": "5b18adae945fcb6f9fbb865dd7dc596f89a63607a4e6617ca9e37f7f10d3386b",
    "corpus/quran-morphology.txt": "742bfac59941b2cb09736d5b7aae694af50792261fb8450cbf6afafcc340645f",
    "corpus/morphology-terms-ar.json": "c9028b44ea859ea23ae57aa1b945f8523203c0d733934d47cef3d729ca8a5db1",
}

TANZIL_LICENSE = ("Tanzil Quran Text © 2007-2021 Tanzil Project — Creative Commons Attribution 3.0. "
                  "يُسمح بنسخ النص وتوزيعه حرفيًا فقط، ولا يجوز تغييره (نص الترخيص كما سجّله المستودع الوسيط).")
CORPUS_LICENSE = ("المصدر الأصلي: Quranic Arabic Corpus v0.4 (Kais Dukes, جامعة ليدز) — يُوزَّع بترخيص GNU GPL "
                  "مع اشتراط نسبة العمل إلى corpus.quran.com. هذه النسخة معدّلة (fork) من mustafa0x/quran-morphology "
                  "وتصحيحاتها من عمل صاحب الـ fork. لم يتسنَّ التحقق المباشر من نص الترخيص على corpus.quran.com "
                  "لأن النطاق محجوب في بيئة التنفيذ؛ يجب التحقق منه قبل أي توزيع علني.")

SOURCES = [
    dict(name="Tanzil Uthmani text (via risan/quran-json)", role="quran_text", version="Tanzil uthmani txt-2 (نسخة 1.1)؛ مستودع risan/quran-json commit 6523a9ad3b73bb7e8cb3a9cdf0ea774b8bab3123",
         url="https://tanzil.net/pub/download/index.php?quranType=uthmani&outType=txt-2&agree=true", path="tanzil/uthmani.json",
         license=TANZIL_LICENSE, license_status="granted (CC BY 3.0, verbatim only)",
         attribution="Tanzil Project — tanzil.net",
         notes="تعذّر التنزيل المباشر من tanzil.net (محجوب بسياسة الشبكة)، فاستُعملت نسخة المستودع الوسيط التي تسجّل بصمة الملف نفسها؛ تطابقت البصمة المحسوبة محليًا مع المسجّلة هناك. لم تُقارَن البصمة بملف tanzil.net مباشرة."),
    dict(name="Tanzil chapter metadata (via risan/quran-json)", role="chapters", version="quran-data.xml",
         url="https://tanzil.net/res/text/metadata/quran-data.xml", path="tanzil/chapters.json",
         license=TANZIL_LICENSE, license_status="granted (CC BY 3.0)", attribution="Tanzil Project — tanzil.net", notes=""),
    dict(name="Quranic Arabic Corpus morphology v0.4 (fork: mustafa0x/quran-morphology)", role="morphology",
         version="fork commit 8f38b39016824284f9ed16ae15069ff9102c4acf (2018-06-19)",
         url="https://github.com/mustafa0x/quran-morphology", path="corpus/quran-morphology.txt",
         license=CORPUS_LICENSE, license_status="unverified_at_origin (GPL حسب الوثائق الثانوية)",
         attribution="Kais Dukes, Quranic Arabic Corpus (corpus.quran.com)؛ وتعديلات mustafa0x",
         notes="الجذور والمداخل مُعدّلة في الـ fork عن v0.4 الأصلي؛ لم أُجرِ مراجعة لغوية لها. كل تحليل يُوسَم «موروث/غير مراجَع»."),
    dict(name="Corpus morphology terms (Arabic glossary)", role="morph_terms", version="same fork commit",
         url="https://github.com/mustafa0x/quran-morphology", path="corpus/morphology-terms-ar.json",
         license=CORPUS_LICENSE, license_status="unverified_at_origin", attribution="mustafa0x / Kais Dukes", notes=""),
]


def verify_raw_files() -> dict:
    """يحسب بصمات الملفات الخام ويقارنها بالمسجّلة. يرفع AssertionError عند أي اختلاف."""
    out = {}
    for rel, expected in EXPECTED_SHA256.items():
        p = config.RAW / rel
        got = sha256_file(p)
        if got != expected:
            raise AssertionError(f"تغيّرت بصمة الملف الخام {rel}: المتوقع {expected} والمحسوب {got}")
        out[rel] = got
    return out


def register_sources(con) -> dict[str, int]:
    ids = {}
    for s in SOURCES:
        p = config.RAW / s["path"]
        sha = sha256_file(p)
        row = con.execute("SELECT id FROM source_versions WHERE name=? AND sha256=?", (s["name"], sha)).fetchone()
        if row:
            ids[s["path"]] = row[0]
            continue
        cur = con.execute(
            "INSERT INTO source_versions(name,role,version,url,local_path,sha256,bytes,license,license_status,attribution,notes,imported_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (s["name"], s["role"], s["version"], s["url"], str(p.relative_to(config.ROOT)), sha, p.stat().st_size,
             s["license"], s["license_status"], s["attribution"], s["notes"], now()))
        ids[s["path"]] = cur.lastrowid
    return ids
