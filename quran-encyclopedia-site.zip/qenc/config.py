"""مسارات المشروع والثوابت."""
from pathlib import Path
import os

ROOT = Path(os.environ.get("QENC_ROOT", Path(__file__).resolve().parent.parent))
RAW = ROOT / "data" / "raw"
OUTPUT = Path(os.environ.get("QENC_OUTPUT", ROOT / "output"))
DB_PATH = Path(os.environ.get("QENC_DB", OUTPUT / "quran.db"))
EXPORT_DIR = OUTPUT / "export"
REPORT_DIR = OUTPUT / "reports"

# أصول البيانات الخام (يُتحقق من بصمتها في sources.py)
TANZIL_TEXT = RAW / "tanzil" / "uthmani.json"
TANZIL_CHAPTERS = RAW / "tanzil" / "chapters.json"
CORPUS_MORPH = RAW / "corpus" / "quran-morphology.txt"
CORPUS_TERMS = RAW / "corpus" / "morphology-terms-ar.json"

EXPECTED_SURAHS = 114
EXPECTED_VERSES = 6236   # عدّ الكوفي (رواية حفص) كما في نص تنزيل

THEMES_DIR = Path(__file__).resolve().parent / "themes"
