"""خط المعالجة الكامل بأمر واحد مع نقاط استئناف.

المراحل: import → index → themes → verify → export → report
كل مرحلة ذرّية (معاملة قاعدة بيانات) ولها بصمة مدخلات؛ تُتخطّى إن اكتملت ببصمة مطابقة (إلا مع --force)،
فيستأنف التشغيل بعد أي انقطاع دون إعادة المكتمل. مراجعات البشر لا تُمسّ.
"""
from __future__ import annotations
import json, traceback
from . import config, db, importer, indexer, verify, export, report
from .themes import assign
from .util import now, sha256_text, sha256_file, jdump
from .sources import EXPECTED_SHA256

STAGES = ["import", "index", "themes", "verify", "export", "report"]


def _themes_inputs_hash(con) -> str:
    parts = []
    from .themes import taxonomy_seed, curated_seed
    parts.append(sha256_file(taxonomy_seed.__file__)); parts.append(sha256_file(curated_seed.__file__)); parts.append(sha256_file(assign.__file__))
    d = config.ROOT / "data" / "ai_proposals"
    if d.exists():
        for f in sorted(d.glob("*.jsonl")):
            parts.append(f.name + sha256_file(f))
    return sha256_text("|".join(parts))


def input_hash(stage: str, con) -> str:
    base = jdump(EXPECTED_SHA256) + sha256_file(importer.__file__) + sha256_file(config.ROOT / "qenc" / "textnorm.py")
    if stage == "import": return sha256_text(base)
    if stage == "index": return sha256_text(base + sha256_file(indexer.__file__))
    if stage == "themes": return sha256_text(base + _themes_inputs_hash(con))
    # المراحل الأخيرة تعتمد على كل ما سبق + حالة الإسنادات (قد تتغير بمراجعة بشرية)
    st = con.execute("SELECT COUNT(*), COALESCE(MAX(id),0), COALESCE(SUM(review_status!='unreviewed'),0) FROM verse_topics").fetchone()
    return sha256_text(base + _themes_inputs_hash(con) + str(tuple(st)) + sha256_file(verify.__file__) + sha256_file(export.__file__) + sha256_file(report.__file__))


def run_stage(con, stage: str, force: bool = False) -> dict:
    h = input_hash(stage, con)
    row = con.execute("SELECT input_hash, status, stats FROM stage_state WHERE stage=?", (stage,)).fetchone()
    if row and row["status"] == "done" and row["input_hash"] == h and not force:
        return {"skipped": True, **json.loads(row["stats"] or "{}")}
    run_id = con.execute("INSERT INTO runs(stage,started_at,status,params) VALUES(?,?,?,?)", (stage, now(), "running", jdump({"force": force}))).lastrowid
    con.commit()
    con.execute("INSERT INTO stage_state(stage,input_hash,status) VALUES(?,?,'running') ON CONFLICT(stage) DO UPDATE SET input_hash=excluded.input_hash, status='running'", (stage, h))
    con.commit()
    try:
        if stage == "import": stats = importer.run(con, run_id)
        elif stage == "index": stats = indexer.run(con, run_id)
        elif stage == "themes": stats = assign.run(con, run_id)
        elif stage == "verify":
            res = verify.run_all(con)
            stats = {"checks": len(res), "passed": sum(r["ok"] for r in res), "failed": [r["name"] for r in res if not r["ok"]], "results": res}
        elif stage == "export": stats = export.run(con)
        elif stage == "report": stats = report.run(con)
        else: raise KeyError(stage)
    except Exception as e:
        con.rollback()
        con.execute("UPDATE runs SET status='failed', finished_at=?, stats=? WHERE id=?", (now(), jdump({"error": repr(e)}), run_id))
        con.execute("INSERT INTO error_log(run_id,stage,severity,ref,message,ts) VALUES(?,?,?,?,?,?)", (run_id, stage, "error", None, traceback.format_exc()[-1500:], now()))
        con.execute("UPDATE stage_state SET status='failed' WHERE stage=?", (stage,))
        con.commit()
        raise
    con.execute("UPDATE runs SET status='done', finished_at=?, stats=? WHERE id=?", (now(), jdump(stats), run_id))
    con.execute("UPDATE stage_state SET status='done', finished_at=?, stats=? WHERE stage=?", (now(), jdump(stats), stage))
    con.commit()
    return stats


def run_all(force: bool = False, until: str | None = None, log=print) -> dict:
    con = db.connect(); db.init_schema(con)
    out = {}
    for st in STAGES:
        log(f"▸ مرحلة {st} …")
        out[st] = run_stage(con, st, force=force)
        log(f"  {'(متخطّاة: مكتملة سابقًا)' if out[st].get('skipped') else 'اكتملت'}")
        if until == st:
            break
    con.close()
    return out
