"""التطبيع الخاص بالبحث.

مبدأ أساسي: النص الأصلي لا يُعدَّل أبدًا. هذه الدوال تُنتج *نسخة بحث* تُخزَّن في أعمدة
وجداول منفصلة، ولا يُكتب ناتجها فوق النص الأصلي.

تعريف التطبيع «ن١» (norm_v1) — موثّق ومحدّد:
  1. حذف التطويل (U+0640) وحذف علامات التشكيل والعلامات القرآنية الصغيرة
     (حركات، شدّة، سكون، ألف خنجرية، علامات الوقف، الميم/الياء/الواو الصغيرة ...).
  2. تحويل الهمزة المركّبة على التطويل (ـٔ) إلى ء، لتتساوى كتابة «الآخرة» بالصورتين.
  3. توحيد أشكال الألف: ٱ أ إ → ا ، و آ → ءا (لأن المصحف يكتبها ءَا)   (تبقى ء ؤ ئ كما هي).
  4. توحيد الياء: ى ي ی → ي.
  5. لا يُمس: ة ، ه ، ء ، ؤ ، ئ.
"""
from __future__ import annotations
import unicodedata

TATWEEL = "ـ"
HAMZA_ABOVE_MARK = "ٔ"
HAMZA_BELOW_MARK = "ٕ"

# نطاقات العلامات التي تُحذف في ن١ (إضافةً إلى كل ما فئته Mn)
_EXTRA_STRIP = set()
for _r in [(0x06D6, 0x06ED), (0x08D3, 0x08FF), (0x0610, 0x061A), (0x064B, 0x065F), (0x0670, 0x0670),
           (0x06E5, 0x06E6)]:  # ۥ ۦ (فئتها Lm) علامات صغيرة
    _EXTRA_STRIP.update(chr(c) for c in range(_r[0], _r[1] + 1))
_EXTRA_STRIP.update({" ", "⁠", "‌", "‍", "‏", "‎"})

_ALEF_MAP = {"ٱ": "ا", "أ": "ا", "إ": "ا", "آ": "ءا"}   # آ = ء + ا لتتساوى مع رسم المصحف «ءا»
_YEH_MAP = {"ى": "ي", "ی": "ي", "ې": "ي"}


def normalize_v1(text: str) -> str:
    out = []
    prev = ""
    for ch in text:
        if ch in (HAMZA_ABOVE_MARK, HAMZA_BELOW_MARK) and prev == TATWEEL:
            out.append("ء")          # ـٔ → ء
            prev = ch
            continue
        if ch == TATWEEL:
            prev = ch
            continue
        if ch in _EXTRA_STRIP or unicodedata.category(ch) == "Mn":
            prev = ch if ch in (HAMZA_ABOVE_MARK, HAMZA_BELOW_MARK) else prev
            continue
        ch = _ALEF_MAP.get(ch, ch)
        ch = _YEH_MAP.get(ch, ch)
        out.append(ch)
        prev = ch
    return "".join(out)


def skeleton(text: str) -> str:
    """هيكل المقارنة المستعمل لمحاذاة نص تنزيل مع أجزاء التحليل الصرفي.

    أشدّ من ن١: يحذف الهمزات المستقلة أيضًا لأن المصدرين يختلفان في رسمها
    (ءَاخِرَة / ـَٔاخِرَة). لا يُستعمل في البحث، بل في التحقق من المحاذاة فقط.
    """
    s = normalize_v1(text)
    return s.replace("ء", "").replace(" ", "")


def is_wordlike(token: str) -> bool:
    return any(unicodedata.category(c).startswith("L") for c in token)
