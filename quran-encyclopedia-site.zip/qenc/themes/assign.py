"""تحميل التصنيف وإسناد الموضوعات إلى الآيات وبناء روابط الكلمات بالموضوعات.

مصادر الإسناد (method):
  lexical_rule   قواعد لفظية: علم PN في الآية = ذكر صاحبه (مباشرة)؛ جذور إشارية = سياقية فقط وبثقة منخفضة.
  seed_curated   إسنادات منتقاة (curated_seed.py) — غير مراجَعة علميًا.
  ai:<provider>  مقترحات نموذج لغوي مستوردة من data/ai_proposals (FileProvider) — غير مؤكدة.
مراجعات البشر (review_status != 'unreviewed') لا تُمسّ ولا تُحذف عند إعادة التشغيل.
"""
from __future__ import annotations
import json, re
from collections import defaultdict
from .. import db
from ..textnorm import normalize_v1
from ..util import now, jdump
from .taxonomy_seed import T, RELATIONS
from .curated_seed import CURATED, SEMANTIC
from .provider import FileProvider, RELEVANCE, ROLES
from .. import config

PN_SQL = """SELECT m.word_id, le.lemma FROM morph_analyses m JOIN lexical_entries le ON le.id=m.lemma_id
            WHERE m.features_raw = 'PN' OR m.features_raw LIKE 'PN|%' OR m.features_raw LIKE '%|PN|%' OR m.features_raw LIKE '%|PN'"""


def load_taxonomy(con):
    with db.tx(con):
        ids = {}
        for slug, parent, name, kind, desc, _roots, _pn in T:
            con.execute("""INSERT INTO topics(slug,name_ar,kind,description,origin,status) VALUES(?,?,?,?,?,?)
                           ON CONFLICT(slug) DO UPDATE SET name_ar=excluded.name_ar, kind=excluded.kind, description=excluded.description""",
                        (slug, name, kind, desc, "seed", "proposed"))
            ids[slug] = con.execute("SELECT id FROM topics WHERE slug=?", (slug,)).fetchone()[0]
        for slug, parent, *_ in T:
            if parent:
                con.execute("UPDATE topics SET parent_id=? WHERE id=?", (ids[parent], ids[slug]))
        for a, b, rel, ev in RELATIONS:
            con.execute("INSERT OR IGNORE INTO topic_relations(topic_a,topic_b,rel_type,evidence,origin) VALUES(?,?,?,?,?)", (ids[a], ids[b], rel, ev, "seed"))
        # مجموعات دلالية
        roots = {r[1]: r[0] for r in con.execute("SELECT id, root FROM roots")}
        for label, rs, note in SEMANTIC:
            con.execute("INSERT OR IGNORE INTO semantic_groups(label,note,origin,status) VALUES(?,?,?,?)", (label, note, "seed_curated", "unreviewed"))
            gid = con.execute("SELECT id FROM semantic_groups WHERE label=?", (label,)).fetchone()[0]
            for r in rs:
                if r in roots:
                    con.execute("INSERT OR IGNORE INTO semantic_members(group_id,root_id) VALUES(?,?)", (gid, roots[r]))
    return ids


def _upsert(con, vt: dict, run_id):
    """يُدرج/يحدّث إسنادًا آليًا دون المساس بما راجعه إنسان."""
    row = con.execute("SELECT id, review_status FROM verse_topics WHERE verse_id=? AND topic_id=? AND method=?",
                      (vt["verse_id"], vt["topic_id"], vt["method"])).fetchone()
    if row:
        if row["review_status"] != "unreviewed":
            return row["id"], "kept_reviewed"
        con.execute("""UPDATE verse_topics SET role=?, relevance=?, rationale=?, evidence_word_ids=?, confidence=?, run_id=? WHERE id=?""",
                    (vt["role"], vt["relevance"], vt["rationale"], jdump(vt["evidence"]), vt["confidence"], run_id, row["id"]))
        return row["id"], "updated"
    cur = con.execute("""INSERT INTO verse_topics(verse_id,topic_id,role,relevance,rationale,evidence_word_ids,method,confidence,review_status,machine_generated,run_id,created_at)
                         VALUES(?,?,?,?,?,?,?,?,'unreviewed',1,?,?)""",
                      (vt["verse_id"], vt["topic_id"], vt["role"], vt["relevance"], vt["rationale"], jdump(vt["evidence"]),
                       vt["method"], vt["confidence"], run_id, now()))
    return cur.lastrowid, "inserted"


def _parse_ref(ref: str):
    m = re.fullmatch(r"(\d+):(\d+)(?:-(\d+))?", ref)
    if not m:
        raise ValueError(ref)
    s, a, b = int(m[1]), int(m[2]), int(m[3] or m[2])
    return [s * 1000 + x for x in range(a, b + 1)]


def run_rules(con, ids, run_id):
    cnt = defaultdict(int)
    pn_by_topic = {slug: {normalize_v1(x) for x in pn} for slug, _p, _n, _k, _d, _r, pn in T if pn}
    root_by_topic = {slug: set(r) for slug, _p, _n, kind, _d, r, _pn in T if r}
    kinds = {slug: kind for slug, _p, _n, kind, *_ in T}
    pn_words = defaultdict(lambda: defaultdict(list))        # verse → lemma_norm → [word_id]
    orig_lemma = {}
    for r in con.execute(PN_SQL):
        pn_words[r["word_id"] // 1000][normalize_v1(r["lemma"])].append(r["word_id"])
        orig_lemma[normalize_v1(r["lemma"])] = r["lemma"]
    root_words = defaultdict(lambda: defaultdict(list))      # verse → root → [word_id]
    for r in con.execute("SELECT wr.word_id, ro.root FROM word_roots wr JOIN roots ro ON ro.id=wr.root_id"):
        root_words[r["word_id"] // 1000][r["root"]].append(r["word_id"])
    seen = set()
    with db.tx(con):
        for slug, pns in pn_by_topic.items():
            for vid, lem in pn_words.items():
                hit = [(l, w) for l, w in lem.items() if l in pns]
                if not hit:
                    continue
                ev = sorted({w for _, ws in hit for w in ws})
                names = "، ".join(sorted({orig_lemma[l] for l, _ in hit}))
                vtid, how = _upsert(con, dict(verse_id=vid, topic_id=ids[slug], role="secondary", relevance="direct",
                                              rationale=f"ورد العلم «{names}» في الآية (وسم PN في المدونة)؛ يثبت الذكر لا تفسير السياق",
                                              evidence=ev, method="lexical_rule", confidence=0.85), run_id)
                seen.add(vtid); cnt[how] += 1
        for slug, rts in root_by_topic.items():
            kind = kinds[slug]
            for vid, rw in root_words.items():
                hit = [r for r in rts if r in rw]
                if not hit:
                    continue
                ev = sorted({w for r in hit for w in rw[r]})
                if kind == "figure":
                    rel, conf, why = "direct", 0.7, f"ورد الجذر الإشاري {'، '.join(sorted(hit))} الخاص بصاحب الموضوع"
                else:
                    rel = "contextual"; conf = min(0.15 + 0.1 * len(hit), 0.45)
                    why = f"إشارة لفظية ضعيفة: جذور {'، '.join(sorted(hit))}؛ لا تُثبت الموضوع وحدها ولا يُعتدّ بها دون مراجعة"
                vtid, how = _upsert(con, dict(verse_id=vid, topic_id=ids[slug], role="secondary", relevance=rel, rationale=why,
                                              evidence=ev, method="lexical_rule", confidence=conf), run_id)
                seen.add(vtid); cnt[how] += 1
        # إزالة إسنادات قاعدية قديمة غير مراجَعة لم تعد تنتجها القواعد
        old = con.execute("SELECT id FROM verse_topics WHERE method='lexical_rule' AND review_status='unreviewed'").fetchall()
        for r in old:
            if r["id"] not in seen:
                con.execute("DELETE FROM verse_topics WHERE id=?", (r["id"],)); cnt["removed_stale"] += 1
    return dict(cnt)


def run_curated(con, ids, run_id):
    cnt = defaultdict(int); seen = set()
    with db.tx(con):
        for slug, refs in CURATED.items():
            for ref in refs:
                for vid in _parse_ref(ref):
                    if not con.execute("SELECT 1 FROM verses WHERE id=?", (vid,)).fetchone():
                        con.execute("INSERT INTO error_log(run_id,stage,severity,ref,message,ts) VALUES(?,?,?,?,?,?)",
                                    (run_id, "themes", "error", f"{vid//1000}:{vid%1000}", f"آية منتقاة غير موجودة ({slug})", now()))
                        continue
                    vtid, how = _upsert(con, dict(verse_id=vid, topic_id=ids[slug], role="secondary", relevance="direct",
                                                  rationale="إسناد منتقى من مطوّر المشروع لآية معروفة المضمون؛ ينتظر مراجعة علمية ولا مرجع تفسيري موثّق له",
                                                  evidence=[], method="seed_curated", confidence=0.8), run_id)
                    seen.add(vtid); cnt[how] += 1
        for r in con.execute("SELECT id FROM verse_topics WHERE method='seed_curated' AND review_status='unreviewed'").fetchall():
            if r["id"] not in seen:
                con.execute("DELETE FROM verse_topics WHERE id=?", (r["id"],)); cnt["removed_stale"] += 1
    return dict(cnt)


def run_ai_import(con, ids, run_id, directory=None):
    directory = directory or (config.ROOT / "data" / "ai_proposals")
    cnt = defaultdict(int)
    if not directory.exists():
        return {"files": 0}
    seen_by_method = defaultdict(set)
    wc = {r[0]: r[1] for r in con.execute("SELECT id, word_count FROM verses")}
    with db.tx(con):
        for d in FileProvider(directory).propose():
            if "_error" in d:
                con.execute("INSERT INTO error_log(run_id,stage,severity,ref,message,ts) VALUES(?,?,?,?,?,?)", (run_id, "themes", "error", None, d["_error"], now())); cnt["rejected"] += 1; continue
            try:
                s, a = map(int, d["verse"].split(":")); vid = s * 1000 + a
                if vid not in wc:
                    raise ValueError("آية غير موجودة")
                provider = str(d.get("provider") or "unknown")
                method = f"ai:{provider}"
                for t in d.get("topics", []):
                    if t["slug"] not in ids:
                        raise ValueError(f"موضوع غير معروف {t['slug']}")
                    if t["relevance"] not in RELEVANCE or t.get("role", "secondary") not in ROLES:
                        raise ValueError("قيمة relevance/role غير صالحة")
                    cue = [int(p) for p in t.get("cue_positions", [])]
                    if any(p < 1 or p > wc[vid] for p in cue):
                        raise ValueError("موضع كلمة خارج الآية")
                    conf = float(t.get("confidence", 0.5))
                    if not 0 <= conf <= 1:
                        raise ValueError("ثقة خارج [0,1]")
                    why = (t.get("rationale") or "").strip()
                    if not why:
                        raise ValueError("سبب فارغ")
                    vtid, how = _upsert(con, dict(verse_id=vid, topic_id=ids[t["slug"]], role=t.get("role", "secondary"), relevance=t["relevance"],
                                                  rationale=why[:400] + f" [مقترح {provider}/{d.get('model','?')}؛ غير مؤكد]",
                                                  evidence=[vid * 1000 + p for p in cue], method=method, confidence=conf), run_id)
                    seen_by_method[method].add(vtid); cnt[how] += 1
            except Exception as e:
                con.execute("INSERT INTO error_log(run_id,stage,severity,ref,message,ts) VALUES(?,?,?,?,?,?)",
                            (run_id, "themes", "error", d.get("_src"), f"رُفض سطر مقترحات: {e}", now())); cnt["rejected"] += 1
        for method, seen in seen_by_method.items():
            for r in con.execute("SELECT id FROM verse_topics WHERE method=? AND review_status='unreviewed'", (method,)).fetchall():
                if r["id"] not in seen:
                    con.execute("DELETE FROM verse_topics WHERE id=?", (r["id"],)); cnt["removed_stale"] += 1
    return dict(cnt)


def build_word_links(con):
    """لكل إسناد: روابط بين كلمات الآية والموضوع؛ is_cue=1 للكلمات الدالة المسجّلة كدليل."""
    with db.tx(con):
        con.execute("DELETE FROM word_topic_links")
        rows = con.execute("SELECT id, verse_id, topic_id, evidence_word_ids FROM verse_topics WHERE review_status!='rejected'").fetchall()
        for r in rows:
            ev = set(json.loads(r["evidence_word_ids"] or "[]"))
            for (wid,) in con.execute("SELECT id FROM words WHERE verse_id=?", (r["verse_id"],)).fetchall():
                con.execute("INSERT OR IGNORE INTO word_topic_links(word_id,topic_id,verse_topic_id,is_cue) VALUES(?,?,?,?)",
                            (wid, r["topic_id"], r["id"], 1 if wid in ev else 0))
    return con.execute("SELECT COUNT(*) FROM word_topic_links").fetchone()[0]


def run(con, run_id=None) -> dict:
    ids = load_taxonomy(con)
    st = {"topics": len(ids)}
    st["rules"] = run_rules(con, ids, run_id)
    st["curated"] = run_curated(con, ids, run_id)
    st["ai_import"] = run_ai_import(con, ids, run_id)
    st["word_topic_links"] = build_word_links(con)
    from .. import intersect
    st["intersection_index_rows"] = intersect.build_index(con)
    return st
