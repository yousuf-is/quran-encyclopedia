"""طبقة مزوّد النموذج اللغوي — مستقلة وقابلة للتبديل.

المبدأ: النماذج *تقترح* تصنيفات؛ لا تُعامل نتائجها حقيقة. تُخزَّن المقترحات مع اسم المزوّد والنموذج وبصمة الأمر
وحالة المراجعة، ولا يُستدعى أي مزوّد عند الاستعلام أبدًا (البحث يعتمد القاعدة المفهرسة فقط).

المزوّدات:
  NullProvider       لا شيء (الوضع الافتراضي دون إنترنت).
  FileProvider       يقرأ ملفات JSONL أنتجتها جلسة خارجية (يدوية أو بنموذج) من data/ai_proposals/ ويتحقق من صحتها.
  AnthropicProvider  يستدعي واجهة Anthropic إن وُجد ANTHROPIC_API_KEY (لم يُشغَّل في بيئة الإنشاء لعدم توفر مفتاح).
صيغة سطر JSONL:
  {"verse":"2:255","provider":"...","model":"...","topics":[{"slug":"tawhid","role":"primary|secondary",
    "relevance":"direct|substantive_indirect|contextual","rationale":"...","cue_positions":[1,2],"confidence":0.0-1.0}]}
"""
from __future__ import annotations
import json, os, hashlib, urllib.request
from abc import ABC, abstractmethod
from pathlib import Path

RELEVANCE = ("direct", "substantive_indirect", "contextual")
ROLES = ("primary", "secondary")


class Provider(ABC):
    name = "abstract"

    @abstractmethod
    def propose(self, verses: list[dict], taxonomy: list[dict]) -> list[dict]:
        """يعيد قائمة أسطر بالصيغة أعلاه."""


class NullProvider(Provider):
    name = "null"
    def propose(self, verses, taxonomy):
        return []


class FileProvider(Provider):
    name = "file"

    def __init__(self, directory):
        self.directory = Path(directory)

    def propose(self, verses=None, taxonomy=None):
        out = []
        for f in sorted(self.directory.glob("*.jsonl")):
            for i, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except json.JSONDecodeError as e:
                    out.append({"_error": f"{f.name}:{i} JSON غير صالح: {e}"})
                    continue
                d["_src"] = f"{f.name}:{i}"
                out.append(d)
        return out


class AnthropicProvider(Provider):
    name = "anthropic"
    URL = "https://api.anthropic.com/v1/messages"

    def __init__(self, model=None, api_key=None):
        self.model = model or os.environ.get("QENC_ANTHROPIC_MODEL", "")
        self.key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not (self.key and self.model):
            raise RuntimeError("يلزم ANTHROPIC_API_KEY وQENC_ANTHROPIC_MODEL")

    def propose(self, verses, taxonomy):
        topics = "\n".join(f"{t['slug']}: {t['name_ar']}" for t in taxonomy)
        body_v = "\n".join(f"{v['surah']}:{v['ayah']} {v['text_original']}" for v in verses)
        prompt = ("صنّف كل آية إلى موضوعات من القائمة فقط (ويجوز ترك الآية بلا موضوع). أعد JSON Lines، سطرًا لكل آية بالصيغة: "
                  '{"verse":"س:آ","topics":[{"slug":"","role":"primary|secondary","relevance":"direct|substantive_indirect|contextual",'
                  '"rationale":"سبب مختصر","cue_positions":[],"confidence":0.0}]}\n\nالموضوعات:\n' + topics + "\n\nالآيات:\n" + body_v)
        req = urllib.request.Request(self.URL, method="POST", data=json.dumps(
            {"model": self.model, "max_tokens": 8000, "messages": [{"role": "user", "content": prompt}]}).encode(),
            headers={"x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:
            txt = json.loads(r.read())["content"][0]["text"]
        h = hashlib.sha256(prompt.encode()).hexdigest()
        out = []
        for line in txt.splitlines():
            line = line.strip()
            if line.startswith("{"):
                try:
                    d = json.loads(line); d.update(provider=self.name, model=self.model, _prompt_hash=h); out.append(d)
                except json.JSONDecodeError:
                    pass
        return out
