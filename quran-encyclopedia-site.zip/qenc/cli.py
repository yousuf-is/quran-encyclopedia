"""سطر الأوامر: python -m qenc <أمر>. كل المخرجات بالعربية."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from . import config, db, pipeline, search, intersect, export


def _con(ro=False):
    c = db.connect(readonly=ro) if config.DB_PATH.exists() or not ro else db.connect()
    return c


def _print_hits(rows, limit):
    hits = search.verse_hits(rows)
    print(f"{len(rows)} موضع في {len(hits)} آية")
    for h in hits[:limit]:
        print(f"{h['surah']}:{h['ayah']} ({h['surah_name']}) مواضع {h['positions']}  {h['verse_text']}")
    if len(hits) > limit:
        print(f"… و{len(hits) - limit} آية أخرى (استعمل --limit أو --export)")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="qenc", description="الموسوعة القرآنية: فهرسة لفظية وموضوعية وتقاطعاتهما")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("run-all", help="تشغيل المعالجة الكاملة بأمر واحد (قابلة للاستئناف)"); p.add_argument("--force", action="store_true"); p.add_argument("--until")
    p = sub.add_parser("stage", help="تشغيل مرحلة واحدة"); p.add_argument("name", choices=pipeline.STAGES); p.add_argument("--force", action="store_true")
    sub.add_parser("status", help="حالة المراحل")
    p = sub.add_parser("search", help="بحث عن كلمة"); p.add_argument("word"); p.add_argument("--level", default="normalized", choices=search.LEVELS); p.add_argument("--limit", type=int, default=20)
    p.add_argument("--export", choices=["csv", "json", "xlsx", "html", "pdf"])
    p = sub.add_parser("root", help="كل الصيغ المرتبطة بجذر"); p.add_argument("root")
    p = sub.add_parser("topic", help="آيات موضوع"); p.add_argument("slug"); p.add_argument("--relevance", default="indirect", choices=["direct", "indirect", "all"]); p.add_argument("--limit", type=int, default=20); p.add_argument("--no-descendants", action="store_true")
    p = sub.add_parser("intersect", help="التقاطع الحقيقي بين كلمة وموضوع"); p.add_argument("word"); p.add_argument("slug")
    p.add_argument("--max-level", default="derivational", choices=["literal", "normalized", "morphological", "derivational"]); p.add_argument("--relevance", default="indirect", choices=["direct", "indirect", "all"])
    p.add_argument("--limit", type=int, default=20); p.add_argument("--export", nargs="*", choices=["csv", "json", "xlsx", "html", "pdf"])
    p = sub.add_parser("verse", help="كلمات الآية وجذورها وموضوعاتها"); p.add_argument("ref")
    sub.add_parser("topics", help="قائمة الموضوعات")
    p = sub.add_parser("dump-verses", help="طباعة آيات (للمراجعة/المزوّدات)"); p.add_argument("start"); p.add_argument("end")
    p = sub.add_parser("serve", help="تشغيل الواجهة"); p.add_argument("--port", type=int, default=8000); p.add_argument("--host", default="127.0.0.1")
    a = ap.parse_args(argv)

    if a.cmd == "run-all":
        out = pipeline.run_all(force=a.force, until=a.until)
        rep = out.get("report", {})
        print(json.dumps({"verify": {k: v for k, v in out.get("verify", {}).items() if k != "results"}}, ensure_ascii=False, indent=1))
        return
    con = db.connect(readonly=True) if a.cmd in ("dump-verses", "verse", "topics", "search", "root", "topic", "intersect") and config.DB_PATH.exists() else db.connect()
    if con.execute("SELECT name FROM sqlite_master WHERE name='verses'").fetchone() is None:
        db.init_schema(con)
    if a.cmd == "stage":
        print(json.dumps(pipeline.run_stage(con, a.name, a.force), ensure_ascii=False, indent=1, default=str)[:4000])
    elif a.cmd == "status":
        for r in con.execute("SELECT stage,status,finished_at FROM stage_state"): print(r["stage"], r["status"], r["finished_at"])
    elif a.cmd == "search":
        rows = search.search(con, a.word, a.level); _print_hits(rows, a.limit)
        if a.export:
            cols = [("surah", "السورة"), ("ayah", "الآية"), ("pos", "الموضع"), ("text_original", "اللفظ"), ("level", "المستوى"), ("reason", "السبب"), ("verse_text", "نص الآية")]
            print(export.write_all(config.EXPORT_DIR / f"search_{a.level}", cols, rows, f"بحث: {a.word} ({a.level})", formats=(a.export,)))
    elif a.cmd == "root":
        for r in search.forms_of(con, a.root): print(f"{r['lemma']:<14} {r['pos'] or '':<3} {r['form']:<18} ×{r['occurrences']} في {r['verses']} آية")
    elif a.cmd == "topic":
        res = intersect.topic_verses(con, a.slug, not a.no_descendants, a.relevance); print(f"{len(res)} آية")
        for v in res[:a.limit]:
            print(f"{v['surah']}:{v['ayah']}  [{', '.join(sorted({x['relevance']+'/'+x['method'] for x in v['assignments']}))}]  {v['verse_text']}")
    elif a.cmd == "intersect":
        r = intersect.intersect(con, a.word, a.slug, a.max_level, True, a.relevance)
        print(f"لفظ: {r['lexical_verses']} آية | موضوع: {r['topic_verses']} آية | التقاطع: {r['counts']}")
        for x in r["intersection"][:a.limit]: print(f"[{x['category']}] {x['surah']}:{x['ayah']}  {x['why']}\n     {x['verse_text']}")
        if a.export:
            cols, rows = export.result_rows(r)
            print(export.write_all(config.EXPORT_DIR / f"intersect_{a.slug}", cols, rows, f"تقاطع: {a.word} × {a.slug}", {"مستوى": a.max_level, "صلة": a.relevance}, formats=tuple(a.export)))
    elif a.cmd == "verse":
        s, ay = map(int, a.ref.split(":")); vid = s * 1000 + ay
        v = con.execute("SELECT * FROM verses WHERE id=?", (vid,)).fetchone()
        print(v["text_original"])
        for w in con.execute("SELECT w.id, w.pos, w.text_original FROM words w WHERE verse_id=? ORDER BY pos", (vid,)):
            roots = [r[0] for r in con.execute("SELECT r.root FROM word_roots wr JOIN roots r ON r.id=wr.root_id WHERE wr.word_id=?", (w["id"],))]
            lem = [r[0] for r in con.execute("SELECT le.lemma FROM word_lemmas wl JOIN lexical_entries le ON le.id=wl.lemma_id WHERE wl.word_id=?", (w["id"],))]
            print(f"  {w['pos']:>2} {w['text_original']:<16} جذر={'/'.join(roots) or '—'} لمّة={'/'.join(lem) or '—'}")
        for t in con.execute("SELECT t.name_ar, vt.relevance, vt.method, vt.review_status, vt.confidence, vt.rationale FROM verse_topics vt JOIN topics t ON t.id=vt.topic_id WHERE verse_id=? ORDER BY vt.relevance", (vid,)):
            print(f"  موضوع: {t[0]} [{t[1]}/{t[2]}/{t[3]}/{t[4]:.2f}] {t[5]}")
    elif a.cmd == "topics":
        for r in con.execute("SELECT t.slug, t.name_ar, t.kind, p.slug AS parent FROM topics t LEFT JOIN topics p ON p.id=t.parent_id ORDER BY t.id"):
            print(f"{r['slug']:<24} {r['name_ar']}  ({r['kind']}{', أب: ' + r['parent'] if r['parent'] else ''})")
    elif a.cmd == "dump-verses":
        s1, a1 = map(int, a.start.split(":")); s2, a2 = map(int, a.end.split(":"))
        for r in con.execute("SELECT surah, ayah, text_original, basmalah_prefix_words FROM verses WHERE id BETWEEN ? AND ? ORDER BY id", (s1 * 1000 + a1, s2 * 1000 + a2)):
            toks = r["text_original"].split(" ")[r["basmalah_prefix_words"]:]
            print(f"{r['surah']}:{r['ayah']}\t" + " ".join(f"{i}.{t}" for i, t in enumerate(toks, 1)))
    elif a.cmd == "serve":
        from .web.app import create_app
        create_app().run(host=a.host, port=a.port)


if __name__ == "__main__":
    main()
