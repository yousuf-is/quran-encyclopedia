"""التصدير: CSV وJSON وExcel وHTML (RTL) وPDF (عبر Chromium عند توفره دون إفساد التشكيل/الاتجاه)."""
from __future__ import annotations
import csv, json, html, io
from pathlib import Path
from . import config

HTML_ROW_LIMIT = 20000


def _cell(v):
    if v is None: return ""
    if isinstance(v, (list, tuple, dict)): return json.dumps(v, ensure_ascii=False)
    return v


def to_csv(path, cols, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:      # BOM ليفتحه Excel بالعربية صحيحًا
        w = csv.writer(f); w.writerow([h for _, h in cols])
        for r in rows: w.writerow([_cell(r.get(k)) for k, _ in cols])


def to_json(path, cols, rows, meta=None):
    data = {"meta": meta or {}, "columns": [k for k, _ in cols], "rows": [{k: r.get(k) for k, _ in cols} for r in rows]}
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=0), encoding="utf-8")


def to_xlsx(path, cols, rows, title="data"):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment
    wb = Workbook(write_only=True)
    import re
    ws = wb.create_sheet(re.sub(r'[\\/*?:\[\]]', '-', title)[:31] or 'data'); ws.sheet_view.rightToLeft = True
    ws.append([h for _, h in cols])
    for r in rows:
        ws.append([_cell(r.get(k)) for k, _ in cols])
    wb.save(path)


HTML_TMPL = """<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>{title}</title>
<style>body{{font-family:'Amiri','Noto Naskh Arabic','Scheherazade New','DejaVu Sans','FreeSerif',serif;margin:2rem;line-height:1.9;color:#111}}
table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #bbb;padding:.3rem .6rem;text-align:right;vertical-align:top}}th{{background:#eee}}
.meta{{color:#555;font-size:.9rem}}</style></head><body><h1>{title}</h1><p class="meta">{meta}</p>
<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></body></html>"""


def to_html(path, cols, rows, title="", meta=""):
    head = "".join(f"<th>{html.escape(h)}</th>" for _, h in cols)
    body = "".join("<tr>" + "".join(f"<td>{html.escape(str(_cell(r.get(k))))}</td>" for k, _ in cols) + "</tr>" for r in rows)
    Path(path).write_text(HTML_TMPL.format(title=html.escape(title), meta=html.escape(meta), head=head, body=body), encoding="utf-8")


def html_to_pdf(html_path, pdf_path) -> bool:
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return False
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_page(); pg.goto(Path(html_path).resolve().as_uri())
            pg.pdf(path=str(pdf_path), format="A4", margin={"top": "15mm", "bottom": "15mm", "left": "12mm", "right": "12mm"}, print_background=True)
            b.close()
        return True
    except Exception:
        return False


def write_all(base: Path, cols, rows, title, meta=None, formats=("csv", "json", "xlsx", "html", "pdf")) -> dict:
    """يكتب base.<ext> لكل صيغة؛ يعيد {الصيغة: المسار أو سبب التخطّي}."""
    base = Path(base); base.parent.mkdir(parents=True, exist_ok=True)
    out = {}
    metas = "؛ ".join(f"{k}: {v}" for k, v in (meta or {}).items())
    if "csv" in formats: to_csv(base.with_suffix(".csv"), cols, rows); out["csv"] = str(base.with_suffix(".csv"))
    if "json" in formats: to_json(base.with_suffix(".json"), cols, rows, meta); out["json"] = str(base.with_suffix(".json"))
    if "xlsx" in formats: to_xlsx(base.with_suffix(".xlsx"), cols, rows, title); out["xlsx"] = str(base.with_suffix(".xlsx"))
    small = len(rows) <= HTML_ROW_LIMIT
    if "html" in formats or "pdf" in formats:
        if small:
            to_html(base.with_suffix(".html"), cols, rows, title, metas)
            if "html" in formats: out["html"] = str(base.with_suffix(".html"))
            if "pdf" in formats:
                out["pdf"] = str(base.with_suffix(".pdf")) if html_to_pdf(base.with_suffix(".html"), base.with_suffix(".pdf")) else "تعذّر (Chromium غير متاح)"
            if "html" not in formats:
                base.with_suffix(".html").unlink(missing_ok=True)
        else:
            out["html"] = out["pdf"] = f"متخطّى: أكثر من {HTML_ROW_LIMIT} صف (استعمل CSV/JSON/Excel)"
    return out


def result_rows(result: dict):
    """يسطّح ناتج intersect.intersect إلى صفوف للتصدير (ويشمل المجموعة الدلالية منفصلة بفئة د)."""
    cols = [("category", "الفئة"), ("surah", "السورة"), ("surah_name", "اسم السورة"), ("ayah", "الآية"), ("verse_text", "نص الآية (الأصلي)"),
            ("words", "الألفاظ المطابقة"), ("lexical_level", "مستوى المطابقة"), ("topics", "الموضوعات/الصلة/الطريقة/المراجعة"),
            ("rationale", "وجه الصلة"), ("disputed", "محل خلاف؟"), ("why", "سبب الإدراج")]
    rows = []
    for r in result["intersection"] + result["synonym_set"]:
        rows.append({"category": r["category"], "surah": r["surah"], "surah_name": r["surah_name"], "ayah": r["ayah"], "verse_text": r["verse_text"],
                     "words": "، ".join(f"{w['text']}@{w['pos']}" for w in r["words"]), "lexical_level": r.get("lexical_level", "semantic"),
                     "topics": "؛ ".join(sorted({f"{a['name_ar']} [{a['relevance']}/{a['method']}/{a['review_status']}/{a['confidence']:.2f}]" for a in r["topic_assignments"]})),
                     "rationale": " | ".join(a["rationale"] or "" for a in r["topic_assignments"])[:600],
                     "disputed": "نعم" if r["disputed"] else "لا", "why": r["why"]})
    return cols, rows


def run(con) -> dict:
    out_dir = config.EXPORT_DIR; out_dir.mkdir(parents=True, exist_ok=True)
    produced = {}
    q = lambda sql: [dict(r) for r in con.execute(sql)]
    fm = ("csv", "json", "xlsx", "html")
    # 1 الآيات
    rows = q("SELECT v.surah, c.name_ar AS surah_name, v.ayah, v.text_original, v.word_count FROM verses v JOIN chapters c ON c.id=v.surah ORDER BY v.id")
    produced["verses"] = write_all(out_dir / "verses", [("surah", "السورة"), ("surah_name", "اسم السورة"), ("ayah", "الآية"), ("text_original", "النص الأصلي (تنزيل)"), ("word_count", "عدد الكلمات")], rows, "نص المصحف بترتيبه", formats=("csv", "json", "xlsx"))
    # 2 الفهرس اللفظي الشامل: كل موضع
    rows = q("""SELECT w.id AS word_id, v.surah, c.name_ar AS surah_name, v.ayah, w.pos, w.text_original, ws.text_norm,
                (SELECT GROUP_CONCAT(DISTINCT le.lemma) FROM word_lemmas wl JOIN lexical_entries le ON le.id=wl.lemma_id WHERE wl.word_id=w.id) AS lemma,
                (SELECT GROUP_CONCAT(DISTINCT r.root) FROM word_roots wr JOIN roots r ON r.id=wr.root_id WHERE wr.word_id=w.id) AS root,
                (SELECT GROUP_CONCAT(m.pos_tag, '+') FROM morph_analyses m WHERE m.word_id=w.id ORDER BY m.seg_index) AS pos_tags,
                (SELECT GROUP_CONCAT(m.features_raw, ' + ') FROM morph_analyses m WHERE m.word_id=w.id ORDER BY m.seg_index) AS features,
                (SELECT f.word_count FROM word_form_map fm JOIN word_forms f ON f.id=fm.form_id AND f.level='literal' WHERE fm.word_id=w.id) AS literal_total,
                (SELECT f.word_count FROM word_form_map fm JOIN word_forms f ON f.id=fm.form_id AND f.level='normalized' WHERE fm.word_id=w.id) AS normalized_total,
                (SELECT COUNT(*) FROM words w2 WHERE w2.verse_id=w.verse_id AND w2.text_original=w.text_original) AS in_verse_count,
                COALESCE((SELECT 'inherited_corpus;' || MIN(m.align_status) FROM morph_analyses m WHERE m.word_id=w.id), 'no_analysis') AS analysis_source
                FROM words w JOIN verses v ON v.id=w.verse_id JOIN chapters c ON c.id=v.surah JOIN word_search ws ON ws.word_id=w.id ORDER BY w.id""")
    cols = [("word_id", "المعرّف"), ("surah", "السورة"), ("surah_name", "اسم السورة"), ("ayah", "الآية"), ("pos", "موضع الكلمة"), ("text_original", "اللفظ كما في المصحف"),
            ("text_norm", "الصيغة المطبّعة (ن١)"), ("lemma", "اللمّة"), ("root", "الجذر"), ("pos_tags", "نوع الأجزاء"), ("features", "السمات الصرفية"),
            ("literal_total", "تكرارها الحرفي في القرآن"), ("normalized_total", "تكرارها المطبّع في القرآن"), ("in_verse_count", "تكرارها في الآية"), ("analysis_source", "مصدر التحليل/المحاذاة")]
    produced["word_index"] = write_all(out_dir / "lexical_index_all_positions", cols, rows, "الفهرس اللفظي الشامل (كل المواضع)", formats=("csv", "json", "xlsx"))
    # 3 الصيغ
    for lvl, nm in (("literal", "forms_literal"), ("normalized", "forms_normalized")):
        rows = q(f"SELECT form, word_count, verse_count FROM word_forms WHERE level='{lvl}' ORDER BY word_count DESC, form")
        produced[nm] = write_all(out_dir / nm, [("form", "الصيغة"), ("word_count", "مرات الورود"), ("verse_count", "عدد الآيات")], rows, f"فهرس الصيغ ({lvl})", formats=fm)
    # 4 الجذور والصيغ
    rows = q("SELECT root, letters, word_count, verse_count FROM roots ORDER BY word_count DESC, root")
    produced["roots"] = write_all(out_dir / "roots_index", [("root", "الجذر"), ("letters", "عدد الحروف"), ("word_count", "عدد الكلمات"), ("verse_count", "عدد الآيات")], rows, "فهرس الجذور", formats=fm)
    rows = q("""SELECT r.root, COALESCE(le.lemma,'—') AS lemma, le.pos AS pos, w.text_original AS form, COUNT(*) AS occurrences, COUNT(DISTINCT w.verse_id) AS verses,
                GROUP_CONCAT((w.verse_id/1000) || ':' || (w.verse_id%1000), ' ') AS refs
                FROM word_roots wr JOIN roots r ON r.id=wr.root_id JOIN words w ON w.id=wr.word_id
                LEFT JOIN word_lemmas wl ON wl.word_id=w.id LEFT JOIN lexical_entries le ON le.id=wl.lemma_id
                GROUP BY r.root, le.lemma, le.pos, w.text_original ORDER BY r.root, lemma, occurrences DESC""")
    produced["root_forms"] = write_all(out_dir / "root_forms_index", [("root", "الجذر"), ("lemma", "اللمّة"), ("pos", "النوع"), ("form", "الصيغة الحرفية"), ("occurrences", "مرات الورود"), ("verses", "عدد الآيات"), ("refs", "المواضع (س:آ)")], rows, "فهرس الجذور والصيغ", formats=("csv", "json", "xlsx"))
    rows = q("""SELECT le.lemma, le.pos, r.root, le.word_count, le.verse_count FROM lexical_entries le LEFT JOIN roots r ON r.id=le.root_id ORDER BY le.word_count DESC, le.lemma""")
    produced["lemmas"] = write_all(out_dir / "lemmas_index", [("lemma", "اللمّة"), ("pos", "النوع"), ("root", "الجذر"), ("word_count", "عدد الكلمات"), ("verse_count", "عدد الآيات")], rows, "فهرس اللمّات (المداخل المعجمية)", formats=("csv", "json", "xlsx"))
    # 5 الموضوعات
    rows = q("""SELECT t.slug, t.name_ar, p.name_ar AS parent, t.kind, t.origin, t.status,
                (SELECT COUNT(DISTINCT vt.verse_id) FROM verse_topics vt WHERE vt.topic_id=t.id AND vt.relevance!='contextual' AND vt.review_status!='rejected') AS verses_direct_or_indirect,
                (SELECT COUNT(DISTINCT vt.verse_id) FROM verse_topics vt WHERE vt.topic_id=t.id AND vt.relevance='contextual' AND vt.review_status!='rejected') AS verses_contextual
                FROM topics t LEFT JOIN topics p ON p.id=t.parent_id ORDER BY t.id""")
    produced["topics"] = write_all(out_dir / "topics_index", [("slug", "المعرّف"), ("name_ar", "الموضوع"), ("parent", "الموضوع الأعلى"), ("kind", "النوع"), ("origin", "المصدر"), ("status", "الحالة"), ("verses_direct_or_indirect", "آيات (مباشرة/جوهرية)"), ("verses_contextual", "آيات (سياقية)")], rows, "فهرس الموضوعات (تصنيف مقترح غير نهائي)", formats=fm)
    rows = q("""SELECT v.surah, c.name_ar AS surah_name, v.ayah, v.text_original, t.name_ar AS topic, vt.role, vt.relevance, vt.rationale, vt.method, vt.confidence, vt.review_status,
                CASE vt.machine_generated WHEN 1 THEN 'آلي' ELSE 'بشري' END AS origin
                FROM verse_topics vt JOIN verses v ON v.id=vt.verse_id JOIN chapters c ON c.id=v.surah JOIN topics t ON t.id=vt.topic_id ORDER BY v.id, t.id""")
    cols = [("surah", "السورة"), ("surah_name", "اسم السورة"), ("ayah", "الآية"), ("text_original", "نص الآية"), ("topic", "الموضوع"), ("role", "الدور"), ("relevance", "تصنيف الصلة"),
            ("rationale", "وجه الصلة/الدليل"), ("method", "الطريقة"), ("confidence", "الثقة"), ("review_status", "حالة المراجعة"), ("origin", "آلي/بشري")]
    produced["verse_topics"] = write_all(out_dir / "thematic_index_verse_topics", cols, rows, "الفهرس الموضوعي: إسناد الآيات", formats=("csv", "json", "xlsx"))
    # 6 فهرس التقاطعات
    rows = q("""SELECT ix.kind, ix.key, t.name_ar AS topic, ix.relevance, ix.verse_count FROM intersection_index ix JOIN topics t ON t.id=ix.topic_id
                WHERE ix.kind IN ('root','lemma') ORDER BY ix.kind, ix.key, t.id""")
    produced["intersections"] = write_all(out_dir / "intersection_index_root_lemma_x_topic", [("kind", "النوع"), ("key", "الجذر/اللمّة"), ("topic", "الموضوع"), ("relevance", "مستوى الصلة"), ("verse_count", "عدد الآيات المشتركة")], rows, "فهرس التقاطع (جذر/لمّة × موضوع) — الصلة المباشرة والجوهرية فقط", formats=("csv", "json", "xlsx"))
    # 7 المواضع غير المحسومة
    rows = q("SELECT stage, severity, ref, message, ts FROM error_log ORDER BY id")
    produced["issues"] = write_all(out_dir / "errors_and_unresolved", [("stage", "المرحلة"), ("severity", "الخطورة"), ("ref", "الموضع"), ("message", "الرسالة"), ("ts", "الوقت")], rows, "الأخطاء والمواضع غير المحسومة", formats=fm)
    return {"files": {k: {fk: fv for fk, fv in v.items()} for k, v in produced.items()}}
