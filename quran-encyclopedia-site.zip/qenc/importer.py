"""استيراد النص القرآني (تنزيل) والتحليل الصرفي (مدونة القرآن) والتحقق من سلامتهما.

قواعد التقسيم الموثّقة:
  * الآية: كما في نص تنزيل (6236 آية). تُخزَّن بنصها الأصلي حرفيًا.
  * الكلمة: ما بين فراغين في نص الآية بعد فصل البسملة المسبوقة في الآية الأولى من كل سورة
    (عدا الفاتحة والتوبة). تُعرَّف البسملة المسبوقة بأنها أول أربع كلمات يطابق هيكلها هيكل بسملة الفاتحة.
  * المحاذاة مع المدونة: تُقارَن سلسلة هياكل الأجزاء الصرفية بسلسلة هياكل كلمات الآية (skeleton)؛
    يُسنَد كل جزء إلى الكلمة التي يبدأ داخلها. أي آية لا تتطابق سلسلتاها تُسجَّل «غير محسومة» ولا يُخمَّن لها تحليل.
"""
from __future__ import annotations
import json, unicodedata
from collections import defaultdict
from . import config, db
from .sources import verify_raw_files, register_sources
from .textnorm import normalize_v1, skeleton, is_wordlike
from .util import sha256_text, now

NORM_VERSION = "norm_v1"


def _log(con, run_id, severity, ref, msg):
    con.execute("INSERT INTO error_log(run_id,stage,severity,ref,message,ts) VALUES(?,?,?,?,?,?)",
                (run_id, "import", severity, ref, msg, now()))


def parse_features(raw: str):
    root = lem = None
    flags = []
    for f in raw.split("|"):
        if f.startswith("ROOT:"):
            root = f[5:]
        elif f.startswith("LEM:"):
            lem = f[4:]
        elif f:
            flags.append(f)
    return root, lem, flags


def load_text():
    data = json.loads(config.TANZIL_TEXT.read_text(encoding="utf-8"))
    return {int(k): v for k, v in data.items()}


def load_morph():
    """{(s,a): [(w, seg, form, tag, feat), ...]} بترتيب الملف."""
    by_verse = defaultdict(list)
    for line in config.CORPUS_MORPH.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        loc, form, tag, feat = line.split("\t")
        s, a, w, g = map(int, loc.split(":"))
        by_verse[(s, a)].append((w, g, form, tag, feat))
    return by_verse


def run(con, run_id=None) -> dict:
    stats = {}
    shas = verify_raw_files()
    stats["raw_sha256"] = shas
    src = register_sources(con)
    text_src, chap_src, morph_src = src["tanzil/uthmani.json"], src["tanzil/chapters.json"], src["corpus/quran-morphology.txt"]

    # --- السور ---
    chapters = json.loads(config.TANZIL_CHAPTERS.read_text(encoding="utf-8"))["chapters"]
    assert len(chapters) == config.EXPECTED_SURAHS, "عدد السور غير 114"
    with db.tx(con):
        for c in chapters:
            con.execute("INSERT OR IGNORE INTO chapters(id,name_ar,name_translit,name_en,revelation_type,verse_count,source_id) VALUES(?,?,?,?,?,?,?)",
                        (c["id"], c["name"], c["transliteration"], c["translation"], c["type"], c["total_verses"], chap_src))

    # --- الآيات والكلمات ---
    text = load_text()
    basm_skel = skeleton(text[1][0]["text"])
    n_verses = n_words = n_basm = 0
    words_by_verse = {}
    with db.tx(con):
        for s in sorted(text):
            for v in text[s]:
                a = v["verse"]
                t = v["text"]
                toks = t.split(" ")
                pref = 0
                if a == 1 and s not in (1, 9):
                    if skeleton(" ".join(toks[:4])) != basm_skel:
                        raise AssertionError(f"لم تُطابَق البسملة المسبوقة في {s}:1")
                    pref = 4
                    n_basm += 1
                body = toks[pref:]
                bad = [x for x in body if not is_wordlike(x)]
                if bad:
                    _log(con, run_id, "warning", f"{s}:{a}", f"رموز غير لفظية استُبعدت من الكلمات: {bad}")
                body = [x for x in body if is_wordlike(x)]
                vid = s * 1000 + a
                con.execute("INSERT OR IGNORE INTO verses(id,surah,ayah,text_original,text_sha256,basmalah_prefix_words,word_count,source_id) VALUES(?,?,?,?,?,?,?,?)",
                            (vid, s, a, t, sha256_text(t), pref, len(body), text_src))
                for i, w in enumerate(body, 1):
                    wid = s * 1_000_000 + a * 1000 + i
                    con.execute("INSERT OR IGNORE INTO words(id,verse_id,pos,text_original) VALUES(?,?,?,?)", (wid, vid, i, w))
                    con.execute("INSERT OR REPLACE INTO word_search(word_id,text_norm,norm_version,text_nfd) VALUES(?,?,?,?)", (wid, normalize_v1(w), NORM_VERSION, unicodedata.normalize("NFD", w)))
                con.execute("INSERT OR REPLACE INTO verse_search(verse_id,text_norm,norm_version) VALUES(?,?,?)",
                            (vid, " ".join(normalize_v1(w) for w in body), NORM_VERSION))
                words_by_verse[(s, a)] = body
                n_verses += 1
                n_words += len(body)
    stats.update(verses=n_verses, words=n_words, basmalah_prefixes_separated=n_basm)

    # --- الصرف ---
    morph = load_morph()
    roots, lemmas = {}, {}
    n_seg = n_unres = n_straddle = 0
    unresolved = []
    expected_segments = sum(len(v) for v in morph.values())
    have = con.execute("SELECT COUNT(*) FROM morph_analyses").fetchone()[0]
    if have == expected_segments:        # استئناف: الصرف مستورد كاملًا من قبل
        stats.update(morph_segments=have, morph_import="skipped_already_complete")
        return stats
    with db.tx(con):
        # تشغيل ناقص سابق: امسح المشتقات الصرفية بترتيب الاعتماد ثم أعد الاستيراد كاملًا (عملية واحدة ذرّية)
        for t in ("word_topic_links", "semantic_members", "word_roots", "word_lemmas", "morph_analyses", "lexical_entries", "roots"):
            con.execute(f"DELETE FROM {t}")
        for (s, a), segs in sorted(morph.items()):
            words = words_by_verse.get((s, a))
            if words is None:
                _log(con, run_id, "unresolved", f"{s}:{a}", "آية في المدونة غير موجودة في النص")
                n_unres += 1
                continue
            wsk = [skeleton(w) for w in words]
            bounds, off = [], 0
            for sk in wsk:
                bounds.append((off, off + len(sk)))
                off += len(sk)
            ssk = [skeleton(f) for (_, _, f, _, _) in segs]
            by_index = False
            if "".join(ssk) != "".join(wsk):
                # احتياط: إن تساوى عدد كلمات المدونة مع عدد كلمات النص أُسنِدت الأجزاء برقم الكلمة (وتُوسَم by_word_index)
                if len({w for (w, _, _, _, _) in segs}) == len(words):
                    by_index = True
                    _log(con, run_id, "warning", f"{s}:{a}", "اختلاف إملائي بين النص والمدونة؛ أُسنِد التحليل برقم الكلمة (by_word_index) ويحتاج مراجعة")
                else:
                    n_unres += 1
                    unresolved.append((s, a))
                    _log(con, run_id, "unresolved", f"{s}:{a}", "عدم تطابق هيكل النص مع هيكل الأجزاء الصرفية وعدد الكلمات؛ لم يُسنَد تحليل لهذه الآية")
                    continue
            off = 0
            seg_counter = defaultdict(int)
            for (w, g, form, tag, feat), sk in zip(segs, ssk):
                start, end = off, off + len(sk)
                off = end
                # الكلمة التي يقع فيها بدء الجزء (الأجزاء الفارغة الهيكل تُسنَد للكلمة السابقة)
                if by_index:
                    widx, straddle = w - 1, False
                else:
                    widx = next((i for i, (b0, b1) in enumerate(bounds) if b0 <= start < b1), None)
                    if widx is None:
                        widx = max(0, len(bounds) - 1) if start >= bounds[-1][1] else 0
                    straddle = end > bounds[widx][1]
                wid = s * 1_000_000 + a * 1000 + widx + 1
                seg_counter[wid] += 1
                root_s, lem_s, flags = parse_features(feat)
                rid = None
                if root_s:
                    rid = roots.get(root_s)
                    if rid is None:
                        rid = con.execute("INSERT INTO roots(root,letters) VALUES(?,?)", (root_s, len(root_s))).lastrowid
                        roots[root_s] = rid
                lid = None
                if lem_s:
                    key = (lem_s, tag, rid)
                    lid = lemmas.get(key)
                    if lid is None:
                        lid = con.execute("INSERT INTO lexical_entries(lemma,lemma_norm,pos,root_id) VALUES(?,?,?,?)",
                                          (lem_s, normalize_v1(lem_s), tag, rid)).lastrowid
                        lemmas[key] = lid
                is_stem = 0 if ("PREF" in flags or "SUFF" in flags) else 1
                con.execute("INSERT INTO morph_analyses(word_id,seg_index,corpus_ref,form_text,pos_tag,features_raw,is_stem,lemma_id,root_id,align_status,source_id,confidence,review_status)"
                            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (wid, seg_counter[wid], f"{s}:{a}:{w}:{g}", form, tag, feat, is_stem, lid, rid,
                             "straddle" if straddle else ("by_word_index" if by_index else "exact"), morph_src, "inherited_corpus", "unreviewed"))
                if straddle:
                    n_straddle += 1
                n_seg += 1
        # مشتقات
        con.execute("DELETE FROM word_roots"); con.execute("DELETE FROM word_lemmas")
        con.execute("INSERT OR IGNORE INTO word_roots SELECT DISTINCT word_id, root_id FROM morph_analyses WHERE root_id IS NOT NULL")
        con.execute("INSERT OR IGNORE INTO word_lemmas SELECT DISTINCT word_id, lemma_id FROM morph_analyses WHERE lemma_id IS NOT NULL AND is_stem=1")
        con.execute("INSERT OR IGNORE INTO word_lemmas SELECT DISTINCT word_id, lemma_id FROM morph_analyses WHERE lemma_id IS NOT NULL AND word_id NOT IN (SELECT word_id FROM word_lemmas)")
    with db.tx(con):
        for r in con.execute("SELECT w.id, w.verse_id, w.pos FROM words w WHERE w.id NOT IN (SELECT word_id FROM morph_analyses)").fetchall():
            _log(con, run_id, "unresolved", f"{r['verse_id']//1000}:{r['verse_id']%1000}:{r['pos']}",
                 "كلمة بلا تحليل صرفي مسنَد: المدونة تضمّ هذا الموضع مع كلمة مجاورة في كلمة واحدة (فرق تقطيع بين المصدرين)")
        for r in con.execute("SELECT corpus_ref, form_text FROM morph_analyses WHERE align_status='straddle'").fetchall():
            _log(con, run_id, "warning", r["corpus_ref"], f"جزء صرفي «{r['form_text']}» يمتدّ عبر حدّ كلمتين في نص تنزيل؛ أُسنِد إلى الكلمة التي يبدأ فيها")
    stats.update(morph_segments=n_seg, segments_straddling_word_boundary=n_straddle,
                 verses_unresolved_alignment=n_unres, roots=len(roots), lexical_entries=len(lemmas))
    return stats
