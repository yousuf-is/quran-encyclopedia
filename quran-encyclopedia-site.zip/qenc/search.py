"""محرك البحث: خمسة مستويات منفصلة لا يُخلط بينها.

  literal      المطابقة الحرفية لتسلسل الرموز كما في النص الأصلي.
  normalized   المطابقة بعد التطبيع ن١ (انظر textnorm).
  morphological  كل كلمة تشترك مع كلمة الاستعلام في اللمّة (المدخل المعجمي) نفسها.
  derivational   كل كلمة فيها جزء جذره أحد جذور كلمة الاستعلام (المطابقة الاشتقاقية).
  semantic     المجموعات الدلالية/المرادفات — مجموعة مستقلة لا تُدمج مع ما سبق.

نتيجة كل مستوى قائمة مواضع (كلمة) مرتّبة بترتيب المصحف مع بيان سبب الإدراج.
"""
from __future__ import annotations
import sqlite3
from .textnorm import normalize_v1

LEVELS = ("literal", "normalized", "morphological", "derivational", "semantic")

_BASE = """SELECT w.id AS word_id, w.verse_id, v.surah, v.ayah, w.pos, w.text_original, c.name_ar AS surah_name, v.text_original AS verse_text
           FROM words w JOIN verses v ON v.id=w.verse_id JOIN chapters c ON c.id=v.surah"""


def _rows(con, where: str, params=(), extra_cols: str = "", join: str = ""):
    sql = _BASE.replace("SELECT w.id AS word_id", f"SELECT {extra_cols + ',' if extra_cols else ''} w.id AS word_id") \
        .replace("JOIN chapters c ON c.id=v.surah", "JOIN chapters c ON c.id=v.surah " + join)
    sql += f" WHERE {where} ORDER BY w.id"
    return [dict(r) for r in con.execute(sql, params)]


def seed_words(con, query: str) -> list[int]:
    """الكلمات التي يُشتق منها الصرف عند طلب مستوى صرفي/اشتقاقي: مطابقة حرفية، ثم مطابقة مطبّعة."""
    import unicodedata
    ids = [r[0] for r in con.execute("SELECT id FROM words WHERE text_original=? OR id IN (SELECT word_id FROM word_search WHERE text_nfd=?)", (query, unicodedata.normalize("NFD", query)))]
    if ids:
        return ids
    return [r[0] for r in con.execute("SELECT word_id FROM word_search WHERE text_norm=?", (normalize_v1(query),))]


def literal(con, query: str):
    """مطابقة حرفية: تطابق تسلسل الرموز كما هو؛ وتُضاف المطابقة بعد توحيد التمثيل العددي القانوني (NFD)
    لكي لا يضيع موضع بسبب اختلاف ترتيب العلامات أو التركيب (لا يُحذف حرف ولا علامة)."""
    import unicodedata
    nfd = unicodedata.normalize("NFD", query)
    rows = _rows(con, "(w.text_original=? OR w.id IN (SELECT word_id FROM word_search WHERE text_nfd=?))", (query, nfd))
    for r in rows:
        r["level"] = "literal"
        r["reason"] = "تطابق حرفي كامل مع الصيغة المطلوبة" if r["text_original"] == query else "تطابق حرفي بعد توحيد التمثيل الرقمي القانوني (NFD) دون حذف أي حرف أو علامة"
    return rows


def normalized(con, query: str):
    n = normalize_v1(query)
    rows = _rows(con, "w.id IN (SELECT word_id FROM word_search WHERE text_norm=?)", (n,))
    for r in rows:
        r["level"] = "normalized"
        r["reason"] = "تطابق بعد التطبيع ن١" + ("" if r["text_original"] == query else f" (الصيغة الأصلية: {r['text_original']})")
    return rows


def lemma_ids_for(con, query: str) -> list[int]:
    seeds = seed_words(con, query)
    ids = set()
    if seeds:
        q = ",".join("?" * len(seeds))
        ids |= {r[0] for r in con.execute(f"SELECT DISTINCT lemma_id FROM word_lemmas WHERE word_id IN ({q})", seeds)}
    # أو أن الاستعلام نفسه لمّة
    ids |= {r[0] for r in con.execute("SELECT id FROM lexical_entries WHERE lemma=? OR lemma_norm=?", (query, normalize_v1(query)))}
    return sorted(ids)


def root_ids_for(con, query: str) -> list[int]:
    ids = {r[0] for r in con.execute("SELECT id FROM roots WHERE root=?", (query,))}
    seeds = seed_words(con, query)
    if seeds:
        q = ",".join("?" * len(seeds))
        ids |= {r[0] for r in con.execute(f"SELECT DISTINCT root_id FROM word_roots WHERE word_id IN ({q})", seeds)}
    if not ids:
        # لا مطابقة لفظية (مثل «صلاة» بالألف مقابل رسم المصحف «صَلَوٰة»): نشتق الجذر من اللمّة المطابقة للاستعلام
        lem = lemma_ids_for(con, query)
        if lem:
            q = ",".join("?" * len(lem))
            ids |= {r[0] for r in con.execute(f"SELECT DISTINCT root_id FROM lexical_entries WHERE id IN ({q}) AND root_id IS NOT NULL", lem)}
    return sorted(ids)


def morphological(con, query: str, lemma_ids: list[int] | None = None):
    lemma_ids = lemma_ids if lemma_ids is not None else lemma_ids_for(con, query)
    if not lemma_ids:
        return []
    q = ",".join("?" * len(lemma_ids))
    rows = _rows(con, f"w.id IN (SELECT word_id FROM word_lemmas WHERE lemma_id IN ({q}))", lemma_ids)
    lem = {r[0]: r[1] for r in con.execute(f"SELECT id, lemma FROM lexical_entries WHERE id IN ({q})", lemma_ids)}
    wl = {}
    for r in con.execute(f"SELECT word_id, lemma_id FROM word_lemmas WHERE lemma_id IN ({q})", lemma_ids):
        wl.setdefault(r[0], []).append(lem[r[1]])
    for r in rows:
        r["level"] = "morphological"; r["lemmas"] = wl.get(r["word_id"], [])
        r["reason"] = "اللمّة نفسها: " + "، ".join(r["lemmas"])
    return rows


def derivational(con, query: str, root_ids: list[int] | None = None):
    root_ids = root_ids if root_ids is not None else root_ids_for(con, query)
    if not root_ids:
        return []
    q = ",".join("?" * len(root_ids))
    rows = _rows(con, f"w.id IN (SELECT word_id FROM word_roots WHERE root_id IN ({q}))", root_ids)
    rt = {r[0]: r[1] for r in con.execute(f"SELECT id, root FROM roots WHERE id IN ({q})", root_ids)}
    wr = {}
    for r in con.execute(f"SELECT word_id, root_id FROM word_roots WHERE root_id IN ({q})", root_ids):
        wr.setdefault(r[0], []).append(rt[r[1]])
    # اللمّات المرتبطة بكل كلمة لتمييز الصيغ
    wl = {}
    for r in con.execute(f"SELECT wl.word_id, le.lemma FROM word_lemmas wl JOIN lexical_entries le ON le.id=wl.lemma_id WHERE wl.word_id IN (SELECT word_id FROM word_roots WHERE root_id IN ({q}))", root_ids):
        wl.setdefault(r[0], []).append(r[1])
    for r in rows:
        r["level"] = "derivational"; r["roots"] = wr.get(r["word_id"], []); r["lemmas"] = wl.get(r["word_id"], [])
        r["reason"] = "الجذر: " + "، ".join(r["roots"])
    return rows


def semantic(con, query: str):
    """مجموعات دلالية يضمّ أحدها جذر الاستعلام. تُعاد منفصلة؛ وتُستثنى كلمات الجذر نفسه من النتيجة."""
    root_ids = root_ids_for(con, query)
    if not root_ids:
        return []
    q = ",".join("?" * len(root_ids))
    groups = con.execute(f"SELECT g.id, g.label, g.status FROM semantic_groups g WHERE g.id IN (SELECT group_id FROM semantic_members WHERE root_id IN ({q}))", root_ids).fetchall()
    out = []
    for g in groups:
        mem = [r[0] for r in con.execute("SELECT root_id FROM semantic_members WHERE group_id=? AND root_id NOT IN (%s)" % q, [g["id"], *root_ids])]
        if not mem:
            continue
        mq = ",".join("?" * len(mem))
        rows = _rows(con, f"w.id IN (SELECT word_id FROM word_roots WHERE root_id IN ({mq}))", mem)
        rt = {r[0]: r[1] for r in con.execute(f"SELECT id, root FROM roots WHERE id IN ({mq})", mem)}
        wr = {}
        for r in con.execute(f"SELECT word_id, root_id FROM word_roots WHERE root_id IN ({mq})", mem):
            wr.setdefault(r[0], []).append(rt[r[1]])
        for r in rows:
            r.update(level="semantic", group=g["label"], group_status=g["status"], roots=wr.get(r["word_id"], []),
                     reason=f"المجموعة الدلالية «{g['label']}» (حالة: {g['status']}) — ليست مطابقة لفظية")
            out.append(r)
    return out


def search(con, query: str, level: str):
    if level not in LEVELS:
        raise ValueError(f"مستوى غير معروف: {level}")
    return globals()[level](con, query)


def verse_hits(rows):
    """تجميع حسب الآية بترتيب المصحف دون تكرار."""
    seen, out = {}, []
    for r in rows:
        k = r["verse_id"]
        if k not in seen:
            seen[k] = {"verse_id": k, "surah": r["surah"], "ayah": r["ayah"], "surah_name": r["surah_name"],
                       "verse_text": r["verse_text"], "positions": [], "words": []}
            out.append(seen[k])
        seen[k]["positions"].append(r["pos"]); seen[k]["words"].append(r["text_original"])
    return sorted(out, key=lambda x: x["verse_id"])


def forms_of(con, root: str):
    """الصيغ المرتبطة بجذر مع تمييز كل صيغة: (لمّة، صيغة حرفية) → عدد."""
    rid = con.execute("SELECT id FROM roots WHERE root=?", (root,)).fetchone()
    if not rid:
        return []
    return [dict(r) for r in con.execute(
        """SELECT COALESCE(le.lemma,'—') AS lemma, le.pos AS pos, w.text_original AS form, COUNT(*) AS occurrences, COUNT(DISTINCT w.verse_id) AS verses
           FROM word_roots wr JOIN words w ON w.id=wr.word_id
           LEFT JOIN word_lemmas wl ON wl.word_id=w.id LEFT JOIN lexical_entries le ON le.id=wl.lemma_id
           WHERE wr.root_id=? GROUP BY le.lemma, le.pos, w.text_original ORDER BY lemma, occurrences DESC""", (rid[0],))]
